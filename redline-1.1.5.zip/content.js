var J=Object.defineProperty;var tt=(s,t,e)=>t in s?J(s,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):s[t]=e;var c=(s,t,e)=>tt(s,typeof t!="symbol"?t+"":t,e);const et={top:0,right:1,bottom:2,left:3},H={"":["top","right","bottom","left"],t:["top"],r:["right"],b:["bottom"],l:["left"],x:["left","right"],y:["top","bottom"],s:["left"],e:["right"]};function L(s){const t=s.trim(),e=t.match(/calc\s*\(\s*(?:var\s*\(\s*--spacing\s*\)\s*\*\s*([\d.]+)|([\d.]+)\s*\*\s*var\s*\(\s*--spacing\s*\))\s*\)/i);if(e){const o=e[1]||e[2];return`spacing-${q(o)}`}const i=t.match(/--spacing\s*\(\s*([^)]+)\s*\)/i);if(i)return D(i[1].trim());const n=t.match(/var\s*\(\s*(--[A-Za-z0-9_-]+)/);if(n){const o=n[1].slice(2);return o==="spacing"?null:o}return null}function q(s){return s.includes(".")?s.replace(/\.?0+$/,""):s}function D(s){if(s.startsWith("--"))return s.slice(2);if(s.startsWith("(")&&s.endsWith(")"))return D(s.slice(1,-1));if(s.startsWith("[")&&s.endsWith("]")){const t=s.slice(1,-1),e=L(t);return e||null}return/^-?\d+(\.\d+)?$/.test(s)?`spacing-${q(s)}`:(/^spacing-.+/.test(s),s)}function S(s,t){const e=s.trim().split(/\s+/).filter(Boolean);return e.length===0?"":e.length===1?e[0]:e.length===2?t===0||t===2?e[0]:e[1]:e.length===3?t===0?e[0]:t===1||t===3?e[1]:e[2]:e[t]}function P(s,t){return s.style.getPropertyValue(t).trim()}function N(s,t,e){var i;for(const n of t){if(n instanceof CSSStyleRule){try{s.matches(n.selectorText)&&e.push(n)}catch{}continue}if(n instanceof CSSMediaRule){const o=(i=n.media)==null?void 0:i.mediaText;(!o||window.matchMedia(o).matches)&&N(s,n.cssRules,e);continue}if(n instanceof CSSSupportsRule)try{CSS.supports(n.conditionText)&&N(s,n.cssRules,e)}catch{}}}function it(s){const t=[];for(const e of Array.from(document.styleSheets))try{N(s,e.cssRules,t)}catch{}return t}function $(s,t){return s.style.getPropertyValue(t).trim()}function nt(s,t,e){const i=s,n=et[e],o=`${t}-${e}`,r=P(i,o);if(r)return r;const d=t,l=P(i,d);if(l)return S(l,n);const p=`${t}-block`,f=P(i,p);if(f&&(e==="top"||e==="bottom"))return S(f,e==="top"?0:1);const g=`${t}-inline`,a=P(i,g);if(a&&(e==="left"||e==="right"))return S(a,e==="left"?0:1);const h=it(s);for(let u=h.length-1;u>=0;u--){const m=h[u],b=$(m,o);if(b)return b;const x=$(m,d);if(x)return S(x,n);const C=$(m,p);if(C&&(e==="top"||e==="bottom"))return S(C,e==="top"?0:1);const v=$(m,g);if(v&&(e==="left"||e==="right"))return S(v,e==="left"?0:1)}return null}function ot(s){const t=s.match(/^-(m(?:[trblxy]|s|e)?)-(.+)$/);if(t){const n=t[1].slice(1),o=D(t[2]);return o?{boxType:"margin",sides:H[n]??H[""],token:o}:null}const e=s.match(/^(p|m)([trblxyse]|)?-(.+)$/);if(!e)return null;const i=D(e[3]);return i?{boxType:e[1]==="p"?"padding":"margin",sides:H[e[2]??""]??H[""],token:i}:null}function st(s,t,e){let i=null;for(let n=0;n<s.classList.length;n++){const o=s.classList[n],r=ot(o);!r||r.boxType!==t||!r.sides.includes(e)||(i={token:r.token,index:n})}return(i==null?void 0:i.token)??null}function rt(s){const t=s.trim();if(!t)return null;const e=document.createElement("div");e.style.position="absolute",e.style.visibility="hidden",e.style.width=t,document.body.appendChild(e);const i=e.getBoundingClientRect().width;if(e.remove(),!i||!isFinite(i)){if(t.endsWith("px"))return parseFloat(t);if(t.endsWith("rem")){const n=parseFloat(getComputedStyle(document.documentElement).fontSize)||16;return parseFloat(t)*n}}return i||null}function at(s){const t=Math.round(s);if(t<=0)return null;const i=getComputedStyle(document.documentElement).getPropertyValue("--spacing").trim();if(!i)return null;const n=rt(i);if(!n||n<=0)return null;const o=t/n,r=Math.round(o);return Math.abs(o-r)>.05?null:`spacing-${r}`}function lt(s,t,e,i){const n=nt(s,t,e);if(n){const r=L(n);if(r)return r}const o=st(s,t,e);return o||at(i)}function dt(s,t,e,i){const n=Math.round(i);if(n<=0)return`${n}`;const o=lt(s,t,e,i);return o?`${o} (${n}px)`:`${n}`}const M=4,w=6,ht=8,ct=5,pt=4,ut=.04,gt=40,ft=160,Z={top:"bottom",bottom:"top",left:"right",right:"left"};function mt(s){const t=["top","right","bottom","left"];if(!t.some(i=>s[i]>0))return[];const e=t.map(i=>Math.round(s[i]));return e.every(i=>i===e[0])?["top"]:t.filter(i=>s[i]>0)}function V(s,t){return mt(t).map(e=>({boxType:s,side:e,pxValue:t[e]}))}function T(s,t,e,i){return new DOMRect(s,t,e,i)}function bt(s){const{elementRect:t,margin:e}=s;return T(t.left-e.left,t.top-e.top,t.width+e.left+e.right,t.height+e.top+e.bottom)}function yt(s){const{elementRect:t,border:e}=s;return T(t.left+e.left,t.top+e.top,t.width-e.left-e.right,t.height-e.top-e.bottom)}function X(s,t){return s==="margin"?bt(t):yt(t)}function vt(s){return T(s.left,s.top,s.width,s.height)}function xt(s){return s.width>=s.height?"top":"bottom"}function wt(s,t){return T(s.left-t,s.top-t,s.width+t*2,s.height+t*2)}function U(s,t){const e=Math.max(0,Math.min(s.right,t.right)-Math.max(s.left,t.left)),i=Math.max(0,Math.min(s.bottom,t.bottom)-Math.max(s.top,t.top));return e*i}function Et(s,t,e){const i=Math.max(0,Math.min(s.right,t)-Math.max(s.left,0)),n=Math.max(0,Math.min(s.bottom,e)-Math.max(s.top,0)),o=Math.max(0,s.width)*Math.max(0,s.height);return Math.max(0,o-i*n)}function Y(s,t,e){return e<t?(t+e)/2:Math.max(t,Math.min(e,s))}function Ct(s,t,e,i,n,o){const r=t.left+t.width/2,d=t.top+t.height/2;let l,p;switch(s){case"top":l=r-e/2,p=t.top-M-i;break;case"bottom":l=r-e/2,p=t.bottom+M;break;case"left":l=t.left-M-e,p=d-i/2;break;case"right":l=t.right+M,p=d-i/2;break}return s==="top"||s==="bottom"?l=Y(l,w,n-w-e):p=Y(p,w,o-w-i),T(l,p,e,i)}function kt(s,t,e){let{left:i,top:n}=s;const{width:o,height:r}=s;return i<w?i=w:i+o>t-w&&(i=t-w-o),n<w?n=w:n+r>e-w&&(n=e-w-r),T(Math.max(0,i),Math.max(0,n),o,r)}function St(s,t){return s===t?0:s===Z[t]?gt:ft}function Lt(s){const t=Z[s];return[s,t,...s==="top"||s==="bottom"?["right","left"]:["bottom","top"]]}function Tt(s,t,e,i,n,o,r,d){let l=St(t,e);l+=Et(s,o,r)*ht;for(const p of i)l+=U(s,p)*ct;for(const p of n)l+=U(s,p)*pt;if(d){const p=d.left+d.width/2,f=d.top+d.height/2,g=s.left+s.width/2,a=s.top+s.height/2;l+=Math.hypot(g-p,a-f)*ut}return l}function At(s=[]){const t=[];for(const e of s)e&&e.width>0&&e.height>0&&t.push(e);return document.querySelectorAll("[data-redline-ui]").forEach(e=>{if(!(e instanceof HTMLElement)||e.hasAttribute("data-redline-overlay"))return;const i=window.getComputedStyle(e);if(i.display==="none"||i.visibility==="hidden"||i.opacity==="0")return;const n=e.getBoundingClientRect();n.width<2||n.height<2||t.push(n)}),t}function Mt(s,t=[],e=null){const i=window.innerWidth,n=window.innerHeight,o=[];for(const{container:l,entries:p}of s)if(p.length!==0){l.style.display="block";for(const{el:f,band:g,side:a}of p){f.style.left="0px",f.style.top="0px",f.style.transform="none",l.appendChild(f);const h=f.getBoundingClientRect();o.push({el:f,band:g,side:a,w:h.width,h:h.height})}}if(o.length===0)return;const r=t.map(l=>wt(l,M)),d=[];for(const l of o){let p=null,f=1/0;for(const a of Lt(l.side)){const h=Ct(a,l.band,l.w,l.h,i,n),u=Tt(h,a,l.side,r,d,i,n,e);u<f&&(f=u,p=h)}const g=kt(p??l.band,i,n);l.el.style.left=`${g.left}px`,l.el.style.top=`${g.top}px`,l.el.style.transform="none",d.push(g)}}const E={background:"#000000",color:"#fff",padding:"6px 10px",borderRadius:"6px",fontSize:"12px",fontWeight:"500",boxShadow:"0 2px 8px rgba(0, 0, 0, 0.3)",fontFamily:"-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"},B={...E,padding:"3px 6px",fontSize:"11px",borderRadius:"3px"},z={...E,padding:"8px 12px",fontSize:"13px"};function Rt(s="medium"){const t=s==="small"?B:s==="large"?z:E;return`
    background: ${t.background};
    color: ${t.color};
    padding: ${t.padding};
    border-radius: ${t.borderRadius};
    font-family: ${t.fontFamily};
    font-size: ${t.fontSize};
    font-weight: ${t.fontWeight};
    white-space: nowrap;
    pointer-events: none;
    box-shadow: ${t.boxShadow};
  `}class F{constructor(t="redline-tooltip-container"){c(this,"container");c(this,"shadow");c(this,"tooltip");c(this,"hideTimeout",null);this.container=document.createElement("div"),this.container.id=t,this.shadow=this.container.attachShadow({mode:"open"}),this.tooltip=document.createElement("div"),this.tooltip.className="tooltip";const e=document.createElement("style");e.textContent=this.getStyles(),this.shadow.appendChild(e),this.shadow.appendChild(this.tooltip)}getStyles(){return`
      :host {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 2147483646;
      }

      .tooltip {
        position: fixed;
        background: ${E.background};
        color: ${E.color};
        padding: ${E.padding};
        border-radius: ${E.borderRadius};
        font-family: ${E.fontFamily};
        font-size: ${E.fontSize};
        font-weight: ${E.fontWeight};
        white-space: nowrap;
        pointer-events: none;
        box-shadow: ${E.boxShadow};
        display: none;
        z-index: 2147483647;
        line-height: 1.3;
      }

      .tooltip.visible {
        display: block;
      }

      /* Size variants */
      .tooltip.small {
        padding: ${B.padding};
        font-size: ${B.fontSize};
        border-radius: ${B.borderRadius};
      }

      .tooltip.large {
        padding: ${z.padding};
        font-size: ${z.fontSize};
      }

      /* Color variants */
      .tooltip.light {
        background: rgba(255, 255, 255, 0.95);
        color: #1a1a2e;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      }

      .tooltip.accent {
        background: #e63946;
        color: #fff;
      }

      /* Content styling — same metrics as tooltip body so labels aren’t visually smaller than values */
      .tooltip .label {
        font-size: inherit;
        font-weight: inherit;
        color: rgba(255, 255, 255, 0.7);
        margin-right: 4px;
      }

      .tooltip .value {
        font-size: inherit;
        font-weight: inherit;
        color: #fff;
      }

      .tooltip.light .label {
        color: rgba(26, 26, 46, 0.6);
      }

      .tooltip.light .value {
        color: #1a1a2e;
      }
    `}show(t){const{content:e,x:i,y:n,size:o="medium",variant:r="dark",offset:d={}}=t;typeof e=="string"?this.tooltip.textContent=e:(this.tooltip.innerHTML="",this.tooltip.appendChild(e)),this.tooltip.className="tooltip visible",o!=="medium"&&this.tooltip.classList.add(o),r!=="dark"&&this.tooltip.classList.add(r);const l=d.x||0,p=d.y||0;this.tooltip.style.left=`${i+l}px`,this.tooltip.style.top=`${n+p}px`,this.container.parentElement||document.body.appendChild(this.container)}showSmart(t){const{content:e,targetRect:i,preferredPosition:n="top",size:o="medium",variant:r="dark",gap:d=8}=t;typeof e=="string"?this.tooltip.textContent=e:(this.tooltip.innerHTML="",this.tooltip.appendChild(e)),this.tooltip.className="tooltip visible",o!=="medium"&&this.tooltip.classList.add(o),r!=="dark"&&this.tooltip.classList.add(r),this.tooltip.style.visibility="hidden",this.tooltip.style.display="block",this.container.parentElement||document.body.appendChild(this.container);const l=this.tooltip.getBoundingClientRect(),p=window.innerWidth,f=window.innerHeight,g=8;let a,h;switch(n){case"top":h=i.top-l.height-d,h<g&&(h=i.bottom+d),a=i.left+i.width/2-l.width/2;break;case"bottom":h=i.bottom+d,h+l.height>f-g&&(h=i.top-l.height-d),a=i.left+i.width/2-l.width/2;break;case"left":a=i.left-l.width-d,a<g&&(a=i.right+d),h=i.top+i.height/2-l.height/2;break;case"right":a=i.right+d,a+l.width>p-g&&(a=i.left-l.width-d),h=i.top+i.height/2-l.height/2;break}a=Math.max(g,Math.min(a,p-l.width-g)),h=Math.max(g,Math.min(h,f-l.height-g)),this.tooltip.style.left=`${a}px`,this.tooltip.style.top=`${h}px`,this.tooltip.style.visibility=""}updatePosition(t,e){this.tooltip.style.left=`${t}px`,this.tooltip.style.top=`${e}px`}updateContent(t){typeof t=="string"?this.tooltip.textContent=t:(this.tooltip.innerHTML="",this.tooltip.appendChild(t))}showTemporary(t,e=1500){this.hideTimeout&&(clearTimeout(this.hideTimeout),this.hideTimeout=null),this.show(t),this.hideTimeout=setTimeout(()=>{this.hide(),this.hideTimeout=null},e)}hide(){this.hideTimeout&&(clearTimeout(this.hideTimeout),this.hideTimeout=null),this.tooltip.classList.remove("visible")}isVisible(){return this.tooltip.classList.contains("visible")}getRect(){if(!this.isVisible())return null;const t=this.tooltip.getBoundingClientRect();return t.width<=0||t.height<=0?null:t}destroy(){this.hideTimeout&&(clearTimeout(this.hideTimeout),this.hideTimeout=null),this.container.parentElement&&this.container.parentElement.removeChild(this.container)}}function Ot(s){const t=document.createElement("span");return s.forEach((e,i)=>{if(i>0&&t.appendChild(document.createTextNode(" ")),e.label){const o=document.createElement("span");o.className="label",o.textContent=e.label,t.appendChild(o)}const n=document.createElement("span");n.className="value",n.textContent=e.value,t.appendChild(n)}),t}function Q(s){const t=s.tagName.toLowerCase(),e=s.id?`#${s.id}`:"",i=Array.from(s.classList).slice(0,3).map(o=>`.${o}`).join("");let n=`<${t}>`;return e&&(n+=e),i&&(n+=i),n}class It{constructor(){c(this,"container");c(this,"shadow");c(this,"box");c(this,"tooltip");c(this,"frozenIndicator");c(this,"marginOverlay");c(this,"borderOverlay");c(this,"paddingOverlay");c(this,"contentOverlay");c(this,"marginLabels");c(this,"paddingLabels");c(this,"gapOverlays");c(this,"gapLabels");c(this,"childrenContainer");c(this,"highlightColor","#e63946");c(this,"showBoxModel",!1);c(this,"isFrozen",!1);c(this,"MARGIN_COLOR","rgba(255, 155, 120, 0.32)");c(this,"BORDER_COLOR","rgba(255, 212, 120, 0.38)");c(this,"PADDING_COLOR","rgba(120, 200, 140, 0.32)");c(this,"MARGIN_LABEL_BG","rgba(230, 100, 80, 0.95)");c(this,"PADDING_LABEL_BG","rgba(80, 160, 100, 0.95)");c(this,"GAP_COLOR","rgba(190, 165, 230, 0.38)");c(this,"GAP_LABEL_BG","rgba(130, 100, 190, 0.95)");this.container=document.createElement("div"),this.container.setAttribute("data-redline-overlay","true"),this.container.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100% !important;
      height: 100% !important;
      pointer-events: none !important;
      z-index: 2147483646 !important;
    `,this.shadow=this.container.attachShadow({mode:"closed"});const t=document.createElement("style");t.textContent=this.getStyles(),this.shadow.appendChild(t),this.marginOverlay=document.createElement("div"),this.marginOverlay.className="box-model-layer margin-layer",this.borderOverlay=document.createElement("div"),this.borderOverlay.className="box-model-layer border-layer",this.paddingOverlay=document.createElement("div"),this.paddingOverlay.className="box-model-layer padding-layer",this.contentOverlay=document.createElement("div"),this.contentOverlay.className="box-model-layer content-layer",this.marginLabels=document.createElement("div"),this.marginLabels.className="box-labels margin-labels",this.paddingLabels=document.createElement("div"),this.paddingLabels.className="box-labels padding-labels",this.gapOverlays=document.createElement("div"),this.gapOverlays.className="gap-overlays",this.gapLabels=document.createElement("div"),this.gapLabels.className="box-labels gap-labels",this.childrenContainer=document.createElement("div"),this.childrenContainer.className="children-outlines",this.box=document.createElement("div"),this.box.className="redline-box",this.tooltip=new F,this.frozenIndicator=document.createElement("div"),this.frozenIndicator.className="frozen-indicator",this.frozenIndicator.textContent="⌘ Frozen",this.shadow.appendChild(this.marginOverlay),this.shadow.appendChild(this.borderOverlay),this.shadow.appendChild(this.paddingOverlay),this.shadow.appendChild(this.contentOverlay),this.shadow.appendChild(this.marginLabels),this.shadow.appendChild(this.paddingLabels),this.shadow.appendChild(this.gapOverlays),this.shadow.appendChild(this.gapLabels),this.shadow.appendChild(this.childrenContainer),this.shadow.appendChild(this.box),this.shadow.appendChild(this.frozenIndicator)}getStyles(){return`
      .redline-box {
        position: fixed;
        pointer-events: none;
        z-index: 2147483646;
        border: 2px solid ${this.highlightColor};
        border-radius: 2px;
        background: transparent;
        box-sizing: border-box;
        display: none;
      }

      .box-model-layer {
        position: fixed;
        pointer-events: none;
        z-index: 2147483644;
        display: none;
      }

      .margin-layer {
        background: ${this.MARGIN_COLOR};
      }

      .padding-layer {
        background: ${this.PADDING_COLOR};
      }

      .border-layer {
        background: ${this.BORDER_COLOR};
      }

      .content-layer {
        background: transparent;
      }

      .box-labels {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: visible;
        pointer-events: none;
        z-index: 2147483647;
        display: none;
      }

      .box-label {
        position: absolute;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Mono', Monaco, monospace;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 6px;
        border-radius: 3px;
        white-space: nowrap;
        color: #fff;
      }

      .box-label--margin,
      .margin-labels .box-label {
        background: ${this.MARGIN_LABEL_BG};
      }

      .box-label--padding,
      .padding-labels .box-label {
        background: ${this.PADDING_LABEL_BG};
      }

      .gap-overlays {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        overflow: visible;
        pointer-events: none;
        z-index: 2147483645;
        display: none;
      }

      .gap-overlays.visible {
        display: block;
      }

      .gap-layer {
        position: fixed;
        pointer-events: none;
        background: ${this.GAP_COLOR};
        box-sizing: border-box;
      }

      .gap-labels .box-label,
      .box-label--gap {
        background: ${this.GAP_LABEL_BG};
      }

      @keyframes redline-shake {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-3px); }
        40% { transform: translateX(3px); }
        60% { transform: translateX(-2px); }
        80% { transform: translateX(2px); }
      }

      .redline-box.shake,
      .box-model-layer.shake,
      .box-labels.shake,
      .gap-overlays.shake {
        animation: redline-shake 0.3s ease-in-out;
      }

      /* Frozen state - dashed border to indicate element is locked */
      .redline-box.frozen {
        border-style: dashed;
        border-color: #ffd93d;
      }

      .frozen-indicator {
        position: fixed;
        background: #ffd93d;
        color: #1a1a2e;
        padding: 4px 8px;
        border-radius: 4px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        z-index: 2147483647;
        pointer-events: none;
        display: none;
      }

      .frozen-indicator.visible {
        display: block;
      }
    `}mount(){this.container.parentElement||document.body.appendChild(this.container),this.tooltip||(this.tooltip=new F)}unmount(){this.tooltip.destroy(),this.tooltip=null,this.container.remove()}highlight(t,e){this.showBoxModel=!0;const i=t.getBoundingClientRect(),n=this.getBoxModelValues(t);this.box.style.top=`${i.top}px`,this.box.style.left=`${i.left}px`,this.box.style.width=`${i.width}px`,this.box.style.height=`${i.height}px`,this.box.style.display="block",this.showBoxModelOverlay(t,i,n),this.updateTooltip(t,i,e),this.renderOverlayLabels(t,i,n,At([this.tooltip.getRect()]))}getBoxModelValues(t){const e=window.getComputedStyle(t),i=n=>parseFloat(n)||0;return{margin:{top:i(e.marginTop),right:i(e.marginRight),bottom:i(e.marginBottom),left:i(e.marginLeft)},border:{top:i(e.borderTopWidth),right:i(e.borderRightWidth),bottom:i(e.borderBottomWidth),left:i(e.borderLeftWidth)},padding:{top:i(e.paddingTop),right:i(e.paddingRight),bottom:i(e.paddingBottom),left:i(e.paddingLeft)}}}showBoxModelOverlay(t,e,i){if(i.margin.top>0||i.margin.right>0||i.margin.bottom>0||i.margin.left>0){const d=e.top-i.margin.top,l=e.left-i.margin.left,p=e.width+i.margin.left+i.margin.right,f=e.height+i.margin.top+i.margin.bottom,g=i.margin.top,a=i.margin.left,h=p-i.margin.right,u=f-i.margin.bottom;this.marginOverlay.style.top=`${d}px`,this.marginOverlay.style.left=`${l}px`,this.marginOverlay.style.width=`${p}px`,this.marginOverlay.style.height=`${f}px`,this.marginOverlay.style.clipPath=`polygon(
        0 0, 100% 0, 100% 100%, 0 100%, 0 0,
        ${a}px ${g}px,
        ${a}px ${u}px,
        ${h}px ${u}px,
        ${h}px ${g}px,
        ${a}px ${g}px
      )`,this.marginOverlay.style.display="block"}else this.marginOverlay.style.display="none";const o=i.padding.top>0||i.padding.right>0||i.padding.bottom>0||i.padding.left>0;if(i.border.top>0||i.border.right>0||i.border.bottom>0||i.border.left>0){const d=e.width,l=e.height,p=i.border.left,f=i.border.top,g=i.border.right,a=i.border.bottom,h=d-p-g,u=l-f-a;if(h>0&&u>0){this.borderOverlay.style.top=`${e.top}px`,this.borderOverlay.style.left=`${e.left}px`,this.borderOverlay.style.width=`${d}px`,this.borderOverlay.style.height=`${l}px`;const m=p,b=f,x=m+h,C=b+u;this.borderOverlay.style.clipPath=`polygon(
          0 0, 100% 0, 100% 100%, 0 100%, 0 0,
          ${m}px ${b}px,
          ${m}px ${C}px,
          ${x}px ${C}px,
          ${x}px ${b}px,
          ${m}px ${b}px
        )`,this.borderOverlay.style.display="block"}else this.borderOverlay.style.display="none"}else this.borderOverlay.style.display="none";if(o){const d=e.top+i.border.top,l=e.left+i.border.left,p=e.width-i.border.left-i.border.right,f=e.height-i.border.top-i.border.bottom,g=i.padding.top,a=i.padding.left,h=p-i.padding.right,u=f-i.padding.bottom;this.paddingOverlay.style.top=`${d}px`,this.paddingOverlay.style.left=`${l}px`,this.paddingOverlay.style.width=`${p}px`,this.paddingOverlay.style.height=`${f}px`,this.paddingOverlay.style.clipPath=`polygon(
        0 0, 100% 0, 100% 100%, 0 100%, 0 0,
        ${a}px ${g}px,
        ${a}px ${u}px,
        ${h}px ${u}px,
        ${h}px ${g}px,
        ${a}px ${g}px
      )`,this.paddingOverlay.style.display="block"}else this.paddingOverlay.style.display="none";this.contentOverlay.style.display="none",this.showGapOverlay(t)}renderOverlayLabels(t,e,i,n){this.marginLabels.innerHTML="",this.paddingLabels.innerHTML="",this.gapLabels.innerHTML="",this.marginLabels.style.display="none",this.paddingLabels.style.display="none",this.gapLabels.style.display="none";const o={elementRect:e,margin:i.margin,border:i.border,padding:i.padding},r=new DOMRect(e.left-i.margin.left,e.top-i.margin.top,e.width+i.margin.left+i.margin.right,e.height+i.margin.top+i.margin.bottom),d=[],l=V("margin",i.margin);if(l.length>0){const g=X("margin",o);d.push({container:this.marginLabels,entries:l.map(a=>({el:this.createBoxModelLabel(t,a.boxType,a.side,a.pxValue),band:g,side:a.side}))})}const p=V("padding",i.padding);if(p.length>0){const g=X("padding",o);d.push({container:this.paddingLabels,entries:p.map(a=>({el:this.createBoxModelLabel(t,a.boxType,a.side,a.pxValue),band:g,side:a.side}))})}const f=this.buildGapLabelBatch(t);f&&d.push(f),Mt(d,n,r)}createBoxModelLabel(t,e,i,n){const o=e==="padding",r=document.createElement("span");return r.className=o?"box-label box-label--padding":"box-label box-label--margin",r.style.background=o?this.PADDING_LABEL_BG:this.MARGIN_LABEL_BG,r.style.color="#fff",r.textContent=dt(t,e,i,n),r}hideBoxModelOverlay(){this.marginOverlay.style.display="none",this.marginOverlay.style.clipPath="none",this.borderOverlay.style.display="none",this.borderOverlay.style.clipPath="none",this.paddingOverlay.style.display="none",this.paddingOverlay.style.clipPath="none",this.contentOverlay.style.display="none",this.marginLabels.style.display="none",this.paddingLabels.style.display="none",this.hideGapOverlay()}resolveGapContainer(t){const e=window.getComputedStyle(t);if(this.isFlexOrGridDisplay(e.display)){const d=this.parseGap(e.rowGap),l=this.parseGap(e.columnGap);if(d>0||l>0)return t}const i=t.parentElement;if(!i)return null;const n=window.getComputedStyle(i);if(!this.isFlexOrGridDisplay(n.display))return null;const o=this.parseGap(n.rowGap),r=this.parseGap(n.columnGap);return o>0||r>0?i:null}getVisibleLayoutChildren(t){return Array.from(t.children).filter(e=>{const i=window.getComputedStyle(e);if(i.display==="none"||i.visibility==="hidden")return!1;const n=e.getBoundingClientRect();return n.width>0&&n.height>0}).map(e=>({el:e,rect:e.getBoundingClientRect()}))}approxMatchesGap(t,e){return e<=0||t<=0?!1:Math.abs(t-e)<=Math.max(2,e*.3)}groupChildrenIntoRows(t,e=8){if(t.length===0)return[];const i=[...t].sort((o,r)=>o.rect.top-r.rect.top||o.rect.left-r.rect.left),n=[[i[0]]];for(let o=1;o<i.length;o++){const r=i[o],d=n[n.length-1],l=d[0].rect.top;Math.abs(r.rect.top-l)<=e?d.push(r):n.push([r])}return n}pushColumnGapRegion(t,e,i,n){if(n<=0)return;const o=e.right,d=i.left-o;if(!this.approxMatchesGap(d,n))return;const l=Math.max(e.top,i.top),p=Math.min(e.bottom,i.bottom);p<=l||t.push({left:o,top:l,width:d,height:p-l,gapPx:n,kind:"column"})}pushRowGapRegion(t,e,i,n,o,r){if(n<=0)return;const d=e.bottom,p=i.top-d;if(!this.approxMatchesGap(p,n))return;const f=Math.max(o,Math.max(e.left,i.left)),g=Math.min(r,Math.min(e.right,i.right));if(g<=f){t.push({left:o,top:d,width:r-o,height:p,gapPx:n,kind:"row"});return}t.push({left:f,top:d,width:g-f,height:p,gapPx:n,kind:"row"})}computeFlexGapRegions(t,e,i,n){const o=[],r=e.flexDirection||"row",d=r.startsWith("row"),l=r.includes("reverse"),p=e.flexWrap!=="nowrap";if(d){const g=this.groupChildrenIntoRows(t);for(const a of g){const h=[...a].sort((u,m)=>l?m.rect.right-u.rect.right:u.rect.left-m.rect.left);for(let u=0;u<h.length-1;u++)this.pushColumnGapRegion(o,h[u].rect,h[u+1].rect,n)}if(p&&g.length>1&&i>0)for(let a=0;a<g.length-1;a++){const h=g[a],u=g[a+1],m=h.reduce((v,A)=>A.rect.bottom>v.rect.bottom?A:v,h[0]).rect,b=u.reduce((v,A)=>A.rect.top<v.rect.top?A:v,u[0]).rect,x=Math.min(...h.map(v=>v.rect.left),...u.map(v=>v.rect.left)),C=Math.max(...h.map(v=>v.rect.right),...u.map(v=>v.rect.right));this.pushRowGapRegion(o,m,b,i,x,C)}return o}const f=this.groupChildrenIntoColumns(t);for(const g of f){const a=[...g].sort((h,u)=>l?u.rect.top-h.rect.top:h.rect.top-u.rect.top);for(let h=0;h<a.length-1;h++)this.pushRowGapRegion(o,a[h].rect,a[h+1].rect,i,Math.min(a[h].rect.left,a[h+1].rect.left),Math.max(a[h].rect.right,a[h+1].rect.right))}if(p&&f.length>1&&n>0)for(let g=0;g<f.length-1;g++){const a=f[g],h=f[g+1],u=a.reduce((b,x)=>x.rect.right>b.rect.right?x:b,a[0]).rect,m=h.reduce((b,x)=>x.rect.left<b.rect.left?x:b,h[0]).rect;this.pushColumnGapRegion(o,u,m,n)}return o}groupChildrenIntoColumns(t,e=8){if(t.length===0)return[];const i=[...t].sort((o,r)=>o.rect.left-r.rect.left||o.rect.top-r.rect.top),n=[[i[0]]];for(let o=1;o<i.length;o++){const r=i[o],d=n[n.length-1],l=d[0].rect.left;Math.abs(r.rect.left-l)<=e?d.push(r):n.push([r])}return n}computeGridGapRegions(t,e,i){const n=[],o=this.groupChildrenIntoRows(t);for(const r of o){const d=[...r].sort((l,p)=>l.rect.left-p.rect.left);for(let l=0;l<d.length-1;l++)this.pushColumnGapRegion(n,d[l].rect,d[l+1].rect,i)}if(o.length>1&&e>0)for(let r=0;r<o.length-1;r++){const d=o[r],l=o[r+1],p=d.reduce((h,u)=>u.rect.bottom>h.rect.bottom?u:h,d[0]).rect,f=l.reduce((h,u)=>u.rect.top<h.rect.top?u:h,l[0]).rect,g=Math.min(...d.map(h=>h.rect.left),...l.map(h=>h.rect.left)),a=Math.max(...d.map(h=>h.rect.right),...l.map(h=>h.rect.right));this.pushRowGapRegion(n,p,f,e,g,a)}return n}computeGapRegions(t){const e=window.getComputedStyle(t);if(!this.isFlexOrGridDisplay(e.display))return[];const i=this.parseGap(e.rowGap),n=this.parseGap(e.columnGap);if(i<=0&&n<=0)return[];const o=this.getVisibleLayoutChildren(t);return o.length<2?[]:e.display.includes("grid")?this.computeGridGapRegions(o,i,n):this.computeFlexGapRegions(o,e,i,n)}formatGapLabel(t,e,i){const n=window.getComputedStyle(t),o=i==="row"?n.rowGap||n.gap:n.columnGap||n.gap,r=L(o)??L(n.gap)??L(n.rowGap)??L(n.columnGap),d=Math.round(e);return r?`${r} (${d}px)`:`${d}`}buildGapLabelBatch(t){const e=this.resolveGapContainer(t);if(!e)return null;const i=this.computeGapRegions(e);if(i.length===0)return null;const n=i.map(o=>{const r=document.createElement("span");return r.className="box-label box-label--gap",r.style.background=this.GAP_LABEL_BG,r.style.color="#fff",r.textContent=this.formatGapLabel(e,o.gapPx,o.kind),{el:r,band:vt(o),side:xt(o)}});return{container:this.gapLabels,entries:n}}showGapOverlay(t){const e=this.resolveGapContainer(t);if(!e){this.hideGapOverlay();return}const i=this.computeGapRegions(e);if(i.length===0){this.hideGapOverlay();return}this.gapOverlays.innerHTML="";for(const n of i){const o=document.createElement("div");o.className="gap-layer",o.style.top=`${n.top}px`,o.style.left=`${n.left}px`,o.style.width=`${n.width}px`,o.style.height=`${n.height}px`,this.gapOverlays.appendChild(o)}this.gapOverlays.classList.add("visible")}hideGapOverlay(){this.gapOverlays.innerHTML="",this.gapOverlays.classList.remove("visible"),this.gapLabels.innerHTML="",this.gapLabels.style.display="none"}parseGap(t){if(!t||t==="normal")return 0;const e=parseFloat(t);return!isFinite(e)||e<=0?0:Math.round(e)}isFlexOrGridDisplay(t){return/(^|\s)(inline-)?(flex|grid)(\s|$)/.test(t)}formatGap(t,e){return t===e?`${t}px`:`${t}px / ${e}px`}computeGapForTooltip(t,e){if(this.isFlexOrGridDisplay(e.display)){const n=this.parseGap(e.rowGap),o=this.parseGap(e.columnGap);if(n>0||o>0)return{label:"gap:",value:this.formatGap(n,o)}}const i=t.parentElement;if(i){const n=window.getComputedStyle(i);if(this.isFlexOrGridDisplay(n.display)){const o=this.parseGap(n.rowGap),r=this.parseGap(n.columnGap);if(o>0||r>0)return{label:"parent gap:",value:this.formatGap(o,r)}}}return null}truncateFontFamilyForTooltip(t,e=44){var o;const i=((o=t.split(",")[0])==null?void 0:o.trim())??t,n=i.startsWith('"')&&i.endsWith('"')||i.startsWith("'")&&i.endsWith("'")?i.slice(1,-1):i;return n.length<=e?n:n.slice(0,Math.max(1,e-1))+"…"}updateTooltip(t,e,i){const n=Q(t),o=Math.round(e.width),r=Math.round(e.height),d=[{value:n},{value:`${o} × ${r}`}],l=i==null?void 0:i.typography;l&&(d.push({label:"font-size:",value:l.fontSize}),d.push({label:"font:",value:this.truncateFontFamilyForTooltip(l.fontFamily)}),l.lineHeight&&l.lineHeight!=="normal"&&d.push({label:"lh:",value:l.lineHeight}));const p=window.getComputedStyle(t),f=this.computeGapForTooltip(t,p);f&&d.push(f);const g=Ot(d);let a=e;if(this.showBoxModel){const h=parseFloat(p.marginTop)||0,u=parseFloat(p.marginBottom)||0,m=parseFloat(p.marginLeft)||0,b=parseFloat(p.marginRight)||0;a=new DOMRect(e.left-m,e.top-h,e.width+m+b,e.height+h+u)}this.tooltip.showSmart({content:g,targetRect:a,preferredPosition:"top",size:"medium",variant:"dark"})}hide(){this.box.style.display="none",this.tooltip.hide(),this.frozenIndicator.classList.remove("visible"),this.box.classList.remove("frozen"),this.hideBoxModelOverlay(),this.clearChildrenHighlight()}highlightChildren(t){this.clearChildrenHighlight();for(const e of t){const i=e.getBoundingClientRect();if(i.width===0||i.height===0)continue;const n=document.createElement("div");n.className="child-outline",n.style.cssText=`
        position: fixed;
        top: ${i.top}px;
        left: ${i.left}px;
        width: ${i.width}px;
        height: ${i.height}px;
        border: 1.5px dashed ${this.highlightColor};
        background: rgba(230, 57, 70, 0.08);
        pointer-events: none;
        box-sizing: border-box;
        z-index: 2147483645;
      `,this.childrenContainer.appendChild(n)}}clearChildrenHighlight(){this.childrenContainer.innerHTML=""}setColor(t){this.highlightColor=t,this.box.style.borderColor=t}shake(){const t=[this.box,this.marginOverlay,this.borderOverlay,this.paddingOverlay,this.marginLabels,this.paddingLabels,this.gapOverlays,this.gapLabels];t.forEach(e=>{e.classList.remove("shake"),e.offsetWidth,e.classList.add("shake")}),setTimeout(()=>{t.forEach(e=>e.classList.remove("shake"))},300)}setFrozen(t){if(this.isFrozen!==t)if(this.isFrozen=t,t){this.box.classList.add("frozen"),this.frozenIndicator.classList.add("visible");const e=parseFloat(this.box.style.top)||0,i=parseFloat(this.box.style.left)||0,n=parseFloat(this.box.style.width)||0;this.frozenIndicator.style.top=`${e-24}px`,this.frozenIndicator.style.left=`${i+n-60}px`;const o=window.innerWidth,r=parseFloat(this.frozenIndicator.style.left);r+60>o&&(this.frozenIndicator.style.left=`${o-68}px`),r<8&&(this.frozenIndicator.style.left="8px"),e<32&&(this.frozenIndicator.style.top=`${e+parseFloat(this.box.style.height)+8}px`)}else this.box.classList.remove("frozen"),this.frozenIndicator.classList.remove("visible")}}class Ht{constructor(){c(this,"elementStack",[]);c(this,"currentIndex",0);c(this,"currentElement",null)}isNavigable(t){return!(!t||t.nodeType!==1||t===document.documentElement||t===document.body||t.hasAttribute("data-redline-overlay")||t.hasAttribute("data-redline-panel")||t.hasAttribute("data-redline-ui")||t.hasAttribute("data-redline-badges")||t.closest("[data-redline-overlay]")||t.closest("[data-redline-panel]")||t.closest("[data-redline-ui]")||t.closest("[data-redline-badges]")||!this.isElementVisible(t))}isElementVisible(t){var r;const e=window.getComputedStyle(t);if(e.visibility==="hidden"||e.visibility==="collapse"||parseFloat(e.opacity)===0)return!1;const n=t.getBoundingClientRect();if(n.width===0||n.height===0)return!1;const o=e.clipPath;if(o&&o!=="none"&&(o==="inset(100%)"||o==="inset(50%)"||o==="polygon(0 0, 0 0, 0 0, 0 0)"||o==="circle(0)"||o==="circle(0px)"||o==="circle(0px at 50% 50%)"))return!1;if(e.overflow==="hidden"){const d=n.width-parseFloat(e.paddingLeft)-parseFloat(e.paddingRight),l=n.height-parseFloat(e.paddingTop)-parseFloat(e.paddingBottom);if(d<=0&&l<=0&&t.children.length===0&&((r=t.textContent)==null?void 0:r.trim())==="")return!1}return!0}updateAtPoint(t,e){const i=document.elementsFromPoint(t,e);this.elementStack=i.filter(n=>this.isStackCandidate(n)),this.selectInnermostLayer()}selectInnermostLayer(){this.currentIndex=0,this.currentElement=this.elementStack[0]??null}isStackCandidate(t){return!(t.hasAttribute("data-redline-overlay")||t.hasAttribute("data-redline-panel")||t.hasAttribute("data-redline-ui")||t.hasAttribute("data-redline-badges")||t.closest("[data-redline-overlay]")||t.closest("[data-redline-panel]")||t.closest("[data-redline-ui]")||t.closest("[data-redline-badges]")||t.tagName==="HTML"||t.tagName==="BODY"||!this.isElementVisible(t))}navigateStackTowardRoot(){return this.currentIndex>=this.elementStack.length-1?this.currentElement:(this.currentIndex+=1,this.currentElement=this.elementStack[this.currentIndex]??null,this.currentElement)}navigateStackTowardLeaf(){return this.currentIndex<=0?this.currentElement:(this.currentIndex-=1,this.currentElement=this.elementStack[this.currentIndex]??null,this.currentElement)}navigateUp(){if(!this.currentElement)return null;let t=this.currentElement.parentElement;for(;t&&!this.isNavigable(t);)t=t.parentElement;if(t){this.currentElement=t;const e=this.elementStack.indexOf(t);e>=0&&(this.currentIndex=e)}return this.currentElement}navigateDown(){if(!this.currentElement)return null;const e=Array.from(this.currentElement.children).find(i=>this.isNavigable(i));if(e){this.currentElement=e;const i=this.elementStack.indexOf(e);i>=0&&(this.currentIndex=i)}return this.currentElement}getChildren(){return this.currentElement?Array.from(this.currentElement.children).filter(t=>this.isNavigable(t)):[]}navigateNext(){if(!this.currentElement)return null;let t=this.currentElement.nextElementSibling;for(;t&&!this.isNavigable(t);)t=t.nextElementSibling;return t&&(this.currentElement=t),this.currentElement}navigatePrevious(){if(!this.currentElement)return null;let t=this.currentElement.previousElementSibling;for(;t&&!this.isNavigable(t);)t=t.previousElementSibling;return t&&(this.currentElement=t),this.currentElement}jumpTo(t){return t>=0&&t<this.elementStack.length&&(this.currentIndex=t,this.currentElement=this.elementStack[t]??null),this.currentElement}getCurrentElement(){return this.currentElement??this.elementStack[this.currentIndex]??null}getCurrentIndex(){return this.currentIndex}getStackSize(){return this.elementStack.length}getStack(){return[...this.elementStack]}getBreadcrumbPath(){const t=this.getCurrentElement();if(!t)return[];const e=[];let i=t;for(;i&&i!==document.documentElement;)e.unshift({tagName:i.tagName.toLowerCase(),id:i.id||null,classes:Array.from(i.classList).slice(0,2),selector:this.getSimpleSelector(i)}),i=i.parentElement;return e}getSimpleSelector(t){const e=t.tagName.toLowerCase();if(t.id)return`${e}#${t.id}`;const i=Array.from(t.classList).slice(0,2);return i.length>0?`${e}.${i.join(".")}`:e}canNavigateUp(){return this.currentIndex<this.elementStack.length-1}canNavigateDown(){return this.currentIndex>0}reset(){this.elementStack=[],this.currentIndex=0,this.currentElement=null}getLayerIndicator(){return this.elementStack.length===0?"":`${this.currentIndex+1} / ${this.elementStack.length}`}}const G=class G{extractLayoutStyles(t){const e=window.getComputedStyle(t),i={};for(const n of G.LAYOUT_PROPERTIES){const o=n.replace(/([A-Z])/g,"-$1").toLowerCase(),r=e.getPropertyValue(o);r&&r!=="none"&&r!=="normal"&&r!=="auto"?i[n]=r:["display","position","overflow","width","height"].includes(n)&&(i[n]=r||"auto")}return i}elementHasRenderableText(t){var i,n,o;if(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement)return t.value.trim().length>0||(((i=t.placeholder)==null?void 0:i.trim().length)??0)>0;if(t instanceof HTMLSelectElement){const r=t.selectedOptions[0];return(((n=r==null?void 0:r.text)==null?void 0:n.trim())??"").length>0}if(t.namespaceURI==="http://www.w3.org/2000/svg"){const r=t.tagName.toLowerCase();return r==="text"||r==="tspan"?(((o=t.textContent)==null?void 0:o.trim().length)??0)>0:!1}const e=t;return typeof e.innerText!="string"?!1:e.innerText.trim().length>0}extractTypographyStyles(t){if(!this.elementHasRenderableText(t))return null;const e=window.getComputedStyle(t);return{fontSize:e.fontSize,fontFamily:e.fontFamily,lineHeight:e.lineHeight}}analyzeHeightChain(t){const e=[];let i=t;for(;i&&i!==document.documentElement;){const n=window.getComputedStyle(i),o=n.height,r=this.hasExplicitHeight(i,n);e.push({tagName:i.tagName.toLowerCase(),selector:this.getSimpleSelector(i),height:o,hasExplicitHeight:r,overflow:n.overflow,isFlexChild:this.isFlexChild(i),isGridChild:this.isGridChild(i)}),i=i.parentElement}return e}hasExplicitHeight(t,e){var n;const i=e.height;if(i.includes("vh")||i.includes("%"))return!0;if(i.endsWith("px")){const o=parseFloat(i),r=(n=t.style)==null?void 0:n.height;if(r&&r!=="auto")return!0;const d=e.minHeight,l=e.maxHeight;if(d!=="0px"&&d!=="auto"||l!=="none"&&l!=="auto")return!0;if(this.isFlexChild(t)){const p=e.flexGrow;if(p&&parseFloat(p)>0)return!0}if(o>=100)return!0}return!1}isFlexChild(t){const e=t.parentElement;if(!e)return!1;const i=window.getComputedStyle(e).display;return i==="flex"||i==="inline-flex"}isGridChild(t){const e=t.parentElement;if(!e)return!1;const i=window.getComputedStyle(e).display;return i==="grid"||i==="inline-grid"}getParentContainerInfo(t){const e=t.parentElement;if(!e||e===document.body)return null;const i=window.getComputedStyle(e),n=i.display;if(!["flex","inline-flex","grid","inline-grid"].includes(n))return null;const o={selector:this.getSimpleSelector(e),tagName:e.tagName.toLowerCase(),display:n,overflow:i.overflow,hasExplicitHeight:this.hasExplicitHeight(e,i)};return n.includes("flex")&&(o.flexDirection=i.flexDirection,o.alignItems=i.alignItems,o.justifyContent=i.justifyContent),n.includes("grid")&&(o.gridTemplateColumns=i.gridTemplateColumns,o.gridTemplateRows=i.gridTemplateRows),o}identifyIssues(t,e,i){const n=[];return(e.overflow==="hidden"||e.overflowY==="hidden")&&n.push("overflow: hidden may clip content"),e.height==="auto"&&(i.some(r=>r.hasExplicitHeight)||n.push("No ancestor with explicit height - element cannot fill available space")),this.isFlexChild(t)&&window.getComputedStyle(t).flexGrow==="0"&&n.push("Flex child with flex-grow: 0 - will not expand to fill space"),n}getSimpleSelector(t){const e=t.tagName.toLowerCase();if(t.id)return`${e}#${t.id}`;const i=Array.from(t.classList).slice(0,2);return i.length>0?`${e}.${i.join(".")}`:e}};c(G,"LAYOUT_PROPERTIES",["display","position","width","height","minWidth","minHeight","maxWidth","maxHeight","boxSizing","margin","padding","overflow","overflowX","overflowY","flexDirection","flexWrap","justifyContent","alignItems","alignSelf","flexGrow","flexShrink","flexBasis","gridTemplateColumns","gridTemplateRows","gridColumn","gridRow","gap"]);let _=G;class Pt{constructor(t={},e){c(this,"container");c(this,"shadow");c(this,"highlightBox");c(this,"linesContainer");c(this,"labelsContainer");c(this,"callbacks");c(this,"enableRulerInteraction");c(this,"showElementHighlightFrame");c(this,"guideColor","#e63946");c(this,"MAX_ELEMENTS",100);c(this,"LINE_CACHE_TTL",120);c(this,"lineElementsCache",new Map);c(this,"rulerLines",[]);c(this,"selectedLine",null);c(this,"hoveredLine",null);c(this,"isShowingElementPreviews",!1);c(this,"isShiftPressed",!1);c(this,"isHybridMode",!1);c(this,"currentElement",null);c(this,"boundHandleKeyDown",null);c(this,"boundHandleKeyUp",null);this.callbacks=t,this.enableRulerInteraction=(e==null?void 0:e.enableRulerInteraction)??!0,this.showElementHighlightFrame=(e==null?void 0:e.showElementHighlightFrame)??!0,this.container=document.createElement("div"),this.container.setAttribute("data-redline-guides","true"),this.container.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100% !important;
      height: 100% !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
    `,this.shadow=this.container.attachShadow({mode:"closed"});const i=document.createElement("style");i.textContent=this.getStyles(),this.shadow.appendChild(i),this.highlightBox=document.createElement("div"),this.highlightBox.className="highlight-box",this.linesContainer=document.createElement("div"),this.linesContainer.className=this.enableRulerInteraction?"guides-lines":"guides-lines guides-lines--passive",this.labelsContainer=document.createElement("div"),this.labelsContainer.className="guides-labels",this.shadow.appendChild(this.highlightBox),this.shadow.appendChild(this.linesContainer),this.shadow.appendChild(this.labelsContainer)}getStyles(){return`
      .highlight-box {
        position: fixed;
        pointer-events: none;
        border: 2px solid ${this.guideColor};
        box-sizing: border-box;
        display: none;
        z-index: 3;
      }

      .guides-lines {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
      }

      .guides-lines--passive .guide-line {
        pointer-events: none !important;
        cursor: default !important;
      }

      @keyframes redline-guides-shake {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-4px); }
        40% { transform: translateX(4px); }
        60% { transform: translateX(-3px); }
        80% { transform: translateX(3px); }
      }

      .highlight-box.shake {
        animation: redline-guides-shake 0.3s ease-in-out;
      }

      .guides-labels {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 2;
      }

      /* Guide lines with larger hit area using padding */
      .guide-line {
        position: fixed;
        background: ${this.guideColor};
        pointer-events: auto;
        opacity: 0.4;
        cursor: pointer;
        transition: opacity 0.15s;
        box-sizing: content-box;
        background-clip: content-box;
      }

      .guide-line:hover {
        opacity: 0.9;
      }

      .guide-line.hovered {
        opacity: 0.7;
      }

      .guide-line.selected {
        opacity: 1;
      }

      /* In hybrid mode, don't show hover effects by default */
      .guide-line.hybrid-mode {
        cursor: default;
        pointer-events: auto;
      }

      .guide-line.hybrid-mode:hover {
        opacity: 0.9;
        cursor: pointer;
      }

      .guide-line.hybrid-mode.hovered {
        opacity: 0.7;
        cursor: pointer;
      }

      .guide-line.hybrid-mode.hovered:hover {
        opacity: 0.9;
      }

      /* Horizontal lines: 1px tall with 6px padding top/bottom for hit area */
      .guide-line-horizontal {
        height: 1px;
        width: 100vw;
        left: 0;
        padding: 6px 0;
        margin-top: -6px;
      }

      .guide-line-horizontal:hover,
      .guide-line-horizontal.selected {
        height: 2px;
        margin-top: -6px;
      }

      /* Vertical lines: 1px wide with 6px padding left/right for hit area */
      .guide-line-vertical {
        width: 1px;
        height: 100vh;
        top: 0;
        padding: 0 6px;
        margin-left: -6px;
      }

      .guide-line-vertical:hover,
      .guide-line-vertical.selected {
        width: 2px;
        margin-left: -6px;
      }

      .guide-line-center {
        opacity: 0.25;
      }

      .guide-line-center:hover {
        opacity: 0.6;
      }

      .guide-line-center.hovered {
        opacity: 0.6;
      }

      /* In hybrid mode, center lines don't show hover by default */
      .guide-line-center.hybrid-mode:hover {
        opacity: 0.6;
      }

      .guide-line-center.hybrid-mode.hovered {
        opacity: 0.6;
      }

      .guide-line-center.hybrid-mode.hovered:hover {
        opacity: 0.6;
      }

      /* Preview highlight (on hover) - dashed border */
      .element-highlight-preview {
        position: fixed;
        border: 2px dashed ${this.guideColor};
        box-sizing: border-box;
        pointer-events: none;
        opacity: 0.4;
        z-index: 4;
        background: rgba(230, 57, 70, 0.05);
      }

      /* Selected highlight (on click) - solid border */
      .element-highlight {
        position: fixed;
        border: 2px solid ${this.guideColor};
        box-sizing: border-box;
        pointer-events: none;
        opacity: 0.6;
        z-index: 4;
        background: rgba(230, 57, 70, 0.1);
      }
    `}mount(){this.container.parentElement||(document.body.appendChild(this.container),this.boundHandleKeyDown=this.handleKeyDown.bind(this),this.boundHandleKeyUp=this.handleKeyUp.bind(this),document.addEventListener("keydown",this.boundHandleKeyDown,!0),document.addEventListener("keyup",this.boundHandleKeyUp,!0))}unmount(){this.container.remove(),this.boundHandleKeyDown&&(document.removeEventListener("keydown",this.boundHandleKeyDown,!0),this.boundHandleKeyDown=null),this.boundHandleKeyUp&&(document.removeEventListener("keyup",this.boundHandleKeyUp,!0),this.boundHandleKeyUp=null)}showGuides(t){this.currentElement=t,this.linesContainer.innerHTML="",this.labelsContainer.innerHTML="",this.rulerLines=[],this.hoveredLine=null;const e=t.getBoundingClientRect();this.showElementHighlightFrame?(this.highlightBox.style.top=`${e.top}px`,this.highlightBox.style.left=`${e.left}px`,this.highlightBox.style.width=`${e.width}px`,this.highlightBox.style.height=`${e.height}px`,this.highlightBox.style.display="block"):this.highlightBox.style.display="none",(!this.isHybridMode||this.isShiftPressed)&&this.drawRulerLines(e)}hide(){this.highlightBox.style.display="none",this.linesContainer.innerHTML="",this.labelsContainer.innerHTML="",this.rulerLines=[],this.selectedLine=null,this.hoveredLine=null,this.currentElement=null}shake(){this.highlightBox.style.display!=="none"&&(this.highlightBox.classList.remove("shake"),this.highlightBox.offsetWidth,this.highlightBox.classList.add("shake"),window.setTimeout(()=>this.highlightBox.classList.remove("shake"),320))}getSelectedLine(){return this.selectedLine}setHybridMode(t){this.isHybridMode=t,this.rulerLines.forEach(e=>{t?e.lineElement.classList.add("hybrid-mode"):e.lineElement.classList.remove("hybrid-mode")})}clearSelection(){this.selectedLine&&(this.selectedLine.lineElement.classList.remove("selected"),this.selectedLine=null),this.shadow.querySelectorAll(".element-highlight").forEach(e=>e.remove())}clearHoverHighlights(){this.hoveredLine&&(this.hoveredLine.lineElement.classList.remove("hovered"),this.hoveredLine=null),this.clearElementPreviews()}clearElementPreviews(){this.shadow.querySelectorAll(".element-highlight-preview").forEach(e=>e.remove())}handleKeyDown(t){if(t.key==="Shift"&&!this.isShiftPressed){if(this.isShiftPressed=!0,this.isHybridMode&&this.currentElement){this.showGuides(this.currentElement);return}!this.isHybridMode&&this.hoveredLine&&!this.selectedLine&&this.showElementPreviews(this.hoveredLine)}}handleKeyUp(t){if(t.key==="Shift"&&this.isShiftPressed){if(this.isShiftPressed=!1,this.isHybridMode&&this.currentElement){this.showGuides(this.currentElement);return}!this.isHybridMode&&this.hoveredLine&&!this.selectedLine&&this.hideElementPreviews()}}showElementPreviews(t){this.isShowingElementPreviews||(t.elements=this.getElementsIntersectingLine(t.orientation,t.position),this.isShowingElementPreviews=!0,t.elements.forEach(e=>{this.highlightElementPreview(e)}))}hideElementPreviews(){this.isShowingElementPreviews&&(this.clearElementPreviews(),this.isShowingElementPreviews=!1)}drawRulerLines(t){const e=t.left+t.width/2,i=t.top+t.height/2;this.createInteractiveLine("horizontal",t.top,"top"),this.createInteractiveLine("horizontal",t.bottom,"bottom"),this.createInteractiveLine("vertical",t.left,"left"),this.createInteractiveLine("vertical",t.right,"right"),this.createInteractiveLine("vertical",e,"centerX","center"),this.createInteractiveLine("horizontal",i,"centerY","center")}getLineCacheKey(t,e){const i=Math.round(e);return[t,i,window.innerWidth,window.innerHeight,window.scrollX,window.scrollY].join(":")}getElementsIntersectingLine(t,e){const i=this.getLineCacheKey(t,e),n=this.lineElementsCache.get(i);if(n&&Date.now()-n.timestamp<this.LINE_CACHE_TTL)return n.elements;const o=new Set,r=window.innerWidth,d=window.innerHeight,f=Math.max(20,Math.ceil((t==="horizontal"?r:d)/120));if(t==="horizontal")for(let h=0;h<r;h+=f){const u=document.elementsFromPoint(h,e);for(const m of u)this.isValidElement(m)&&o.add(m)}else for(let h=0;h<d;h+=f){const u=document.elementsFromPoint(e,h);for(const m of u)this.isValidElement(m)&&o.add(m)}const g=Array.from(o);g.sort((h,u)=>{const m=this.getElementDepth(h);return this.getElementDepth(u)-m});const a=g.slice(0,this.MAX_ELEMENTS);return this.lineElementsCache.size>50&&this.lineElementsCache.clear(),this.lineElementsCache.set(i,{timestamp:Date.now(),elements:a}),a}isValidElement(t){if(t.hasAttribute("data-redline-overlay")||t.hasAttribute("data-redline-panel")||t.hasAttribute("data-redline-guides")||t.hasAttribute("data-redline-ui")||t.hasAttribute("data-redline-badges"))return!1;const e=t.tagName.toUpperCase();if(e==="HTML"||e==="BODY"||e==="SCRIPT"||e==="STYLE")return!1;const i=t.getBoundingClientRect();return!(i.width===0||i.height===0)}getElementDepth(t){let e=0,i=t;for(;i&&i!==document.documentElement;)e++,i=i.parentElement;return e}createInteractiveLine(t,e,i,n="edge"){const o=document.createElement("div");o.className=`guide-line guide-line-${t}`,n==="center"&&o.classList.add("guide-line-center"),this.isHybridMode&&o.classList.add("hybrid-mode"),t==="horizontal"?o.style.top=`${e}px`:o.style.left=`${e}px`;const r=this.getElementsIntersectingLine(t,e),d={orientation:t,position:e,type:i,elements:r,lineElement:o};return this.rulerLines.push(d),this.enableRulerInteraction&&(o.addEventListener("mouseenter",()=>{this.handleLineHover(d)}),o.addEventListener("mouseleave",()=>{this.handleLineHover(null)}),o.addEventListener("click",l=>{l.stopPropagation(),this.handleLineClick(d,{x:l.clientX,y:l.clientY})})),this.linesContainer.appendChild(o),o}handleLineHover(t){this.selectedLine||this.isHybridMode&&!this.isShiftPressed||(this.clearHoverHighlights(),this.isShowingElementPreviews=!1,t&&(this.hoveredLine=t,t.lineElement.classList.add("hovered"),this.isShiftPressed&&!this.isHybridMode&&this.showElementPreviews(t)),this.callbacks.onLineHover&&this.callbacks.onLineHover(t))}handleLineClick(t,e){this.clearSelection(),this.clearHoverHighlights(),t.elements=this.getElementsIntersectingLine(t.orientation,t.position),this.selectedLine=t,t.lineElement.classList.add("selected"),t.elements.forEach(i=>{this.highlightElement(i)}),this.callbacks.onLineClick&&this.callbacks.onLineClick(t,e)}highlightElementPreview(t){const e=t.getBoundingClientRect(),i=document.createElement("div");i.className="element-highlight-preview",i.style.top=`${e.top}px`,i.style.left=`${e.left}px`,i.style.width=`${e.width}px`,i.style.height=`${e.height}px`,this.labelsContainer.appendChild(i)}highlightElement(t){const e=t.getBoundingClientRect(),i=document.createElement("div");i.className="element-highlight",i.style.top=`${e.top}px`,i.style.left=`${e.left}px`,i.style.width=`${e.width}px`,i.style.height=`${e.height}px`,this.labelsContainer.appendChild(i)}}class $t{constructor(t={}){c(this,"isActive",!1);c(this,"callbacks");c(this,"alignmentGuides");c(this,"highlightOverlay");c(this,"styleAnalyzer");c(this,"layerNavigator");c(this,"copyFeedbackTooltip");c(this,"currentElement",null);c(this,"boundHandleMouseMove");c(this,"boundHandleClick");c(this,"boundHandleKeyDown");c(this,"boundHandleScroll");this.callbacks=t,this.layerNavigator=new Ht,this.styleAnalyzer=new _,this.highlightOverlay=new It,this.copyFeedbackTooltip=new F("redline-copy-feedback-tooltip"),this.alignmentGuides=new Pt({},{enableRulerInteraction:!1,showElementHighlightFrame:!1}),this.boundHandleMouseMove=this.handleMouseMove.bind(this),this.boundHandleClick=this.handleClick.bind(this),this.boundHandleKeyDown=this.handleKeyDown.bind(this),this.boundHandleScroll=this.handleScroll.bind(this)}activate(){this.isActive||(this.isActive=!0,this.alignmentGuides.mount(),this.highlightOverlay.mount(),document.addEventListener("mousemove",this.boundHandleMouseMove,!0),document.addEventListener("click",this.boundHandleClick,!0),document.addEventListener("keydown",this.boundHandleKeyDown,!0),window.addEventListener("scroll",this.boundHandleScroll,!0),document.body.style.cursor="crosshair")}deactivate(){var t,e;this.isActive&&(this.isActive=!1,document.removeEventListener("mousemove",this.boundHandleMouseMove,!0),document.removeEventListener("click",this.boundHandleClick,!0),document.removeEventListener("keydown",this.boundHandleKeyDown,!0),window.removeEventListener("scroll",this.boundHandleScroll,!0),this.highlightOverlay.hide(),this.highlightOverlay.unmount(),this.copyFeedbackTooltip.hide(),this.alignmentGuides.hide(),this.alignmentGuides.unmount(),document.body.style.cursor="",this.currentElement=null,this.layerNavigator.reset(),(e=(t=this.callbacks).onDeactivate)==null||e.call(t))}toggle(){this.isActive?this.deactivate():this.activate()}getIsActive(){return this.isActive}handleMouseMove(t){var o,r;if(!this.isActive)return;const e=t.target;if(e.closest("[data-redline-guides]")||e.closest("[data-redline-overlay]")||e.closest("[data-redline-ui]"))return;this.layerNavigator.updateAtPoint(t.clientX,t.clientY);const i=this.layerNavigator.getCurrentElement();if(!i)return;const n=i!==this.currentElement;this.currentElement=i,this.alignmentGuides.showGuides(i),this.syncHighlightOverlay(i),n&&((r=(o=this.callbacks).onHover)==null||r.call(o,i))}handleClick(t){if(!this.isActive)return;const e=t.target;if(e.closest("[data-redline-guides]")||e.closest("[data-redline-overlay]")||e.closest("[data-redline-ui]"))return;const i=this.currentElement??this.layerNavigator.getCurrentElement();if(!i)return;const n=Q(i);this.copyTextToClipboard(n).then(o=>{var r,d;!o||!this.isActive||((d=(r=this.callbacks).onCopy)==null||d.call(r),this.copyFeedbackTooltip.showTemporary({content:`Copied: ${n}`,x:t.clientX,y:t.clientY,size:"small",offset:{x:12,y:12}},1500))}),t.preventDefault(),t.stopPropagation()}async copyTextToClipboard(t){try{return await navigator.clipboard.writeText(t),!0}catch{try{const e=document.createElement("textarea");e.value=t,e.style.position="fixed",e.style.left="-9999px",document.body.appendChild(e),e.select();const i=document.execCommand("copy");return document.body.removeChild(e),i}catch{return!1}}}syncHighlightOverlay(t){this.highlightOverlay.highlight(t,{typography:this.styleAnalyzer.extractTypographyStyles(t)})}handleKeyDown(t){var r,d,l,p,f,g,a,h,u,m;if(!this.isActive)return;const e=t.target,n=t.composedPath()[0];if(!((e.tagName==="INPUT"||e.tagName==="TEXTAREA"||n.tagName==="INPUT"||n.tagName==="TEXTAREA")&&t.key!=="Escape"))switch(t.key){case"Escape":(d=(r=this.callbacks).onEscape)==null||d.call(r),this.deactivate(),t.preventDefault();break;case"ArrowUp":t.preventDefault(),this.layerNavigator.navigateStackTowardRoot(),this.applyCurrentNavigatorElement(),(p=(l=this.callbacks).onArrowKey)==null||p.call(l,"up");break;case"ArrowDown":t.preventDefault(),this.layerNavigator.navigateStackTowardLeaf(),this.applyCurrentNavigatorElement(),(g=(f=this.callbacks).onArrowKey)==null||g.call(f,"down");break;case"ArrowRight":t.preventDefault(),this.layerNavigator.navigateNext(),this.applyCurrentNavigatorElement(),(h=(a=this.callbacks).onArrowKey)==null||h.call(a,"right");break;case"ArrowLeft":t.preventDefault(),this.layerNavigator.navigatePrevious(),this.applyCurrentNavigatorElement(),(m=(u=this.callbacks).onArrowKey)==null||m.call(u,"left");break}}handleScroll(){!this.isActive||!this.currentElement||(this.alignmentGuides.showGuides(this.currentElement),this.syncHighlightOverlay(this.currentElement))}applyCurrentNavigatorElement(){const t=this.layerNavigator.getCurrentElement();t&&(this.currentElement=t,this.alignmentGuides.showGuides(t),this.syncHighlightOverlay(t))}}const y=class y{constructor(t){c(this,"container",null);c(this,"redlineButton",null);c(this,"collapseButton",null);c(this,"buttonsContainer",null);c(this,"callbacks");c(this,"isCollapsed",!1);c(this,"ready",Promise.resolve());c(this,"isDragging",!1);c(this,"dragStartX",0);c(this,"dragStartLeft",0);c(this,"boundHandleDragStart",null);c(this,"boundHandleDragMove",null);c(this,"boundHandleDragEnd",null);c(this,"boundHandleDoubleClick",null);c(this,"expandActivationTimeout",null);this.callbacks=t}mount(){this.container||(this.createElements(),this.attachStyles(),this.attachEventListeners(),this.container.classList.add("redline-no-transition"),this.container.style.display="none",document.body.appendChild(this.container),this.ready=Promise.all([this.loadCollapseState(),this.loadPosition()]).then(()=>{requestAnimationFrame(()=>{requestAnimationFrame(()=>{var t;(t=this.container)==null||t.classList.remove("redline-no-transition")})})}))}whenReady(){return this.ready}unmount(){this.container&&(this.boundHandleDragStart&&this.container.removeEventListener("mousedown",this.boundHandleDragStart),this.boundHandleDoubleClick&&this.container.removeEventListener("dblclick",this.boundHandleDoubleClick),this.boundHandleDragMove&&document.removeEventListener("mousemove",this.boundHandleDragMove),this.boundHandleDragEnd&&document.removeEventListener("mouseup",this.boundHandleDragEnd),this.container.remove(),this.container=null,this.redlineButton=null,this.collapseButton=null,this.buttonsContainer=null,this.boundHandleDragStart=null,this.boundHandleDragMove=null,this.boundHandleDragEnd=null,this.boundHandleDoubleClick=null)}show(){this.container&&(this.container.style.display="flex")}hide(){this.container&&(this.container.style.display="none")}setRedlineActive(t){if(this.redlineButton){const e=t?y.ICON_ACTIVE:y.ICON_INACTIVE,i='<span class="btn-tooltip">Redline</span>';this.redlineButton.innerHTML=e+i,this.redlineButton.classList.toggle("redline-fab--active",t),this.redlineButton.setAttribute("aria-pressed",String(t))}}createElements(){this.container=document.createElement("div"),this.container.id="redline-floating-button",this.container.setAttribute("data-redline-ui","true"),this.buttonsContainer=document.createElement("div"),this.buttonsContainer.className="redline-buttons-container",this.redlineButton=document.createElement("button"),this.redlineButton.className="redline-fab",this.redlineButton.innerHTML=`
      ${y.ICON_INACTIVE}
      <span class="btn-tooltip">Redline</span>
    `,this.redlineButton.setAttribute("aria-label","Toggle Redline Mode"),this.redlineButton.setAttribute("aria-pressed","false"),this.collapseButton=document.createElement("button"),this.collapseButton.className="redline-collapse-btn",this.collapseButton.innerHTML=y.ICON_CHEVRON_DOWN,this.collapseButton.setAttribute("aria-label","Collapse buttons"),this.collapseButton.title="Collapse buttons",this.buttonsContainer.appendChild(this.redlineButton),this.buttonsContainer.appendChild(this.collapseButton),this.container.appendChild(this.buttonsContainer)}attachStyles(){const t="redline-fab-styles";if(document.getElementById(t))return;const e=document.createElement("style");e.id=t,e.textContent=`
      #redline-floating-button {
        position: fixed;
        bottom: 8px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483646;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        transition: bottom 0.2s ease;
        cursor: grab;
      }

      #redline-floating-button.dragging {
        cursor: grabbing;
        transition: none;
      }

      /* Suppress all transitions while initial persisted state is being applied
         (collapse + position) so reloads don't animate from defaults. */
      #redline-floating-button.redline-no-transition,
      #redline-floating-button.redline-no-transition *,
      #redline-floating-button.redline-no-transition *::before,
      #redline-floating-button.redline-no-transition *::after {
        transition: none !important;
        animation: none !important;
      }

      /* Container content wrapper */
      .redline-buttons-container {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        padding: 4px;
        background: #000000;
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 24px;
        box-shadow: 
          0 4px 12px rgba(0, 0, 0, 0.15),
          0 1px 3px rgba(0, 0, 0, 0.1);
        user-select: none;
        transition: all 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
      }

      .redline-fab {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border: none;
        border-radius: 50%;
        background: transparent;
        color: white;
        cursor: pointer;
        transition: all 0.45s cubic-bezier(0.34, 1.35, 0.64, 1), 
                    filter 0.45s cubic-bezier(0.34, 1.35, 0.64, 1),
                    transform 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
        outline: none;
        padding: 0;
        position: relative;
      }

      .redline-fab:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
      }

      .redline-fab:active {
        background: rgba(255, 255, 255, 0.15);
      }

      .redline-fab--active {
        background: #e63946;
        color: white;
      }

      .redline-fab--active:hover {
        background: #d62839;
        color: white;
      }

      .redline-fab svg {
        flex-shrink: 0;
      }

      /* Tooltip styling - unified */
      .btn-tooltip {
        position: absolute;
        bottom: calc(100% + 8px);
        left: 50%;
        transform: translateX(-50%) translateY(4px);
        ${Rt("small")}
        opacity: 0;
        transition: opacity 0.2s ease, transform 0.2s ease;
        z-index: 1000;
      }

      .redline-fab:hover .btn-tooltip {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }

      /* Collapse button - looks like part of the container when expanded */
      .redline-collapse-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border: none;
        border-radius: 50%;
        background: transparent;
        color: white;
        cursor: pointer;
        transition: all 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
        outline: none;
        padding: 0;
      }

      .redline-collapse-btn svg {
        flex-shrink: 0;
        transition: transform 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
      }

      .redline-collapse-btn:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
      }

      .redline-collapse-btn:active {
        background: rgba(255, 255, 255, 0.15);
      }

      /* Collapsed state - slide down and show only chevron */
      #redline-floating-button.collapsed {
        bottom: 0px;
      }

      #redline-floating-button.collapsed .redline-buttons-container {
        border-radius: 8px 8px 0 0;
        box-shadow: 
          0 -2px 8px rgba(0, 0, 0, 0.15);
        padding: 2px;
        gap: 0px;
        width: fit-content;
        margin: 0 auto;
      }

      #redline-floating-button.collapsed .redline-fab {
        width: 0;
        height: 0;
        min-width: 0;
        min-height: 0;
        padding: 0;
        margin: 0;
        opacity: 0;
        overflow: hidden;
        filter: blur(4px);
        transform: scale(0.3);
      }

      #redline-floating-button.collapsed .redline-collapse-btn {
        width: 24px;
        height: 16px;
        border-radius: 6px 6px 0 0;
        margin: 0;
      }

      #redline-floating-button.collapsed .redline-collapse-btn svg {
        transform: rotate(180deg);
      }
    `,document.head.appendChild(e)}attachEventListeners(){var e,i,n,o;const t=r=>{r.key===" "&&(r.preventDefault(),r.stopPropagation())};(e=this.redlineButton)==null||e.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),this.callbacks.onToggleRedline()}),(i=this.redlineButton)==null||i.addEventListener("keydown",t),(n=this.collapseButton)==null||n.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),this.toggleCollapse()}),(o=this.collapseButton)==null||o.addEventListener("keydown",t),this.boundHandleDragStart=this.handleDragStart.bind(this),this.boundHandleDragMove=this.handleDragMove.bind(this),this.boundHandleDragEnd=this.handleDragEnd.bind(this),this.container&&this.container.addEventListener("mousedown",this.boundHandleDragStart),document.addEventListener("mousemove",this.boundHandleDragMove),document.addEventListener("mouseup",this.boundHandleDragEnd),this.boundHandleDoubleClick=this.handleDoubleClick.bind(this),this.container&&this.container.addEventListener("dblclick",this.boundHandleDoubleClick)}getIsCollapsed(){return this.isCollapsed}expand(){var t,e,i;this.isCollapsed&&(this.isCollapsed=!1,this.saveCollapseState(),this.container&&(this.container.classList.remove("collapsed"),(t=this.collapseButton)==null||t.setAttribute("aria-label","Collapse buttons"),this.collapseButton&&(this.collapseButton.title="Collapse buttons")),(i=(e=this.callbacks).onCollapse)==null||i.call(e,!1))}toggleCollapse(){var e,i,n,o;const t=this.isCollapsed;this.isCollapsed=!this.isCollapsed,this.saveCollapseState(),this.container&&(this.isCollapsed?(this.container.classList.add("collapsed"),(e=this.collapseButton)==null||e.setAttribute("aria-label","Expand buttons"),this.collapseButton.title="Expand buttons"):(this.container.classList.remove("collapsed"),(i=this.collapseButton)==null||i.setAttribute("aria-label","Collapse buttons"),this.collapseButton.title="Collapse buttons")),(o=(n=this.callbacks).onCollapse)==null||o.call(n,this.isCollapsed),t&&!this.isCollapsed&&this.scheduleRedlineActivationOnExpand()}scheduleRedlineActivationOnExpand(){this.expandActivationTimeout&&(window.clearTimeout(this.expandActivationTimeout),this.expandActivationTimeout=null);const t=this.buttonsContainer;if(!t){this.callbacks.onToggleRedline();return}let e=!1;const i=()=>{e||(e=!0,t.removeEventListener("transitionend",n),this.expandActivationTimeout&&(window.clearTimeout(this.expandActivationTimeout),this.expandActivationTimeout=null),this.callbacks.onToggleRedline())},n=o=>{o.target===t&&i()};t.addEventListener("transitionend",n),this.expandActivationTimeout=window.setTimeout(i,500)}async loadCollapseState(){var t,e;try{const n=(await chrome.storage.local.get(y.STORAGE_KEY))[y.STORAGE_KEY];(n===!0||n==="true")&&(this.isCollapsed=!0,(t=this.container)==null||t.classList.add("collapsed"),(e=this.collapseButton)==null||e.setAttribute("aria-label","Expand buttons"),this.collapseButton.title="Expand buttons")}catch(i){console.warn("Failed to load collapse state:",i)}}async saveCollapseState(){try{await chrome.storage.local.set({[y.STORAGE_KEY]:this.isCollapsed})}catch(t){console.warn("Failed to save collapse state:",t)}}handleDragStart(t){if(!t.target.closest(".redline-fab, .redline-collapse-btn")){if(this.isDragging=!0,this.dragStartX=t.clientX,this.container){const e=this.container.getBoundingClientRect();this.dragStartLeft=e.left+e.width/2,this.container.classList.add("dragging")}t.preventDefault()}}handleDragMove(t){if(!this.isDragging||!this.container)return;const e=t.clientX-this.dragStartX;let i=this.dragStartLeft+e;const n=window.innerWidth,o=n/2,r=Math.abs(i-o),d=60;if(r<d){const p=1-r/d,f=(o-i)*p*.3;i+=f}const l=i/n*100;this.container.style.left=`${l}%`}handleDragEnd(){if(this.isDragging&&(this.isDragging=!1,this.container)){this.container.classList.remove("dragging");const t=this.container.getBoundingClientRect(),e=t.left+t.width/2,i=window.innerWidth/2;Math.abs(e-i)<40?this.centerContainer():this.savePosition()}}handleDoubleClick(t){t.target.closest(".redline-fab, .redline-collapse-btn")||this.centerContainer()}centerContainer(){this.container&&(this.container.style.left="50%",this.savePosition())}async loadPosition(){try{const e=(await chrome.storage.local.get(y.STORAGE_POSITION_KEY))[y.STORAGE_POSITION_KEY];typeof e=="string"&&this.container&&(this.container.style.left=e)}catch(t){console.warn("Failed to load position:",t)}}async savePosition(){try{if(this.container){const t=this.container.style.left||"50%";await chrome.storage.local.set({[y.STORAGE_POSITION_KEY]:t})}}catch(t){console.warn("Failed to save position:",t)}}};c(y,"STORAGE_KEY","redline-floating-button-collapsed"),c(y,"STORAGE_POSITION_KEY","redline-floating-button-position"),c(y,"ICON_INACTIVE",`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M10 15v-3"/>
      <path d="M14 15v-3"/>
      <path d="M18 15v-3"/>
      <path d="M2 8V4"/>
      <path d="M22 6H2"/>
      <path d="M22 8V4"/>
      <path d="M6 15v-3"/>
      <rect x="2" y="12" width="20" height="8" rx="2"/>
    </svg>
  `),c(y,"ICON_ACTIVE",`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M10 15v-3"/>
      <path d="M14 15v-3"/>
      <path d="M18 15v-3"/>
      <path d="M2 8V4"/>
      <path d="M22 6H2"/>
      <path d="M22 8V4"/>
      <path d="M6 15v-3"/>
      <rect x="2" y="12" width="20" height="8" rx="2"/>
    </svg>
  `),c(y,"ICON_CHEVRON_DOWN",`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m6 9 6 6 6-6"/>
    </svg>
  `);let W=y;const R="redline-onboarding-step",k="redline-onboarding-step2-progress",O={hovered:!1,copied:!1,usedUp:!1,usedDown:!1,exited:!1},I=class I{constructor(t={}){c(this,"step",0);c(this,"step2Progress",{...O});c(this,"autoAdvanceTimer",null);c(this,"stepTransitionTimer",null);c(this,"container",null);c(this,"rafId",null);c(this,"boundHandleResize",null);c(this,"callbacks");this.callbacks=t}getStep(){return this.step}applyStep(t){this.step!==t&&(this.step=t,this.render())}applyStep2Progress(t){this.step2Progress={...t},this.step===2&&(this.applyChecklistDOMState(),this.maybeAutoAdvanceFromStep2())}async setStep(t){var i,n,o,r;const e={[R]:t};if(t===2&&this.step!==2?(this.step2Progress={...O},e[k]=this.step2Progress):t===0&&(this.step2Progress={...O},e[k]=this.step2Progress),this.step===t){await chrome.storage.local.set(e);return}this.step=t,await chrome.storage.local.set(e),this.render(),t===0?(n=(i=this.callbacks).onComplete)==null||n.call(i):(r=(o=this.callbacks).onAdvance)==null||r.call(o,t)}notifyInspectorActivated(){this.step===1&&this.setStep(2)}notifyHover(){this.step!==2||this.step2Progress.hovered||this.updateStep2Progress({hovered:!0})}notifyCopy(){this.step!==2||this.step2Progress.copied||this.updateStep2Progress({copied:!0})}notifyArrow(t){this.step===2&&(t==="up"&&!this.step2Progress.usedUp?this.updateStep2Progress({usedUp:!0}):t==="down"&&!this.step2Progress.usedDown&&this.updateStep2Progress({usedDown:!0}))}notifyEscape(){this.step!==2||this.step2Progress.exited||this.updateStep2Progress({exited:!0})}notifyShortcutUsed(){this.step===3&&this.setStep(0)}unmount(){this.stopTracking(),this.autoAdvanceTimer!==null&&(window.clearTimeout(this.autoAdvanceTimer),this.autoAdvanceTimer=null),this.stepTransitionTimer!==null&&(window.clearTimeout(this.stepTransitionTimer),this.stepTransitionTimer=null),this.boundHandleResize&&(window.removeEventListener("resize",this.boundHandleResize),this.boundHandleResize=null),this.container&&(this.container.remove(),this.container=null)}async updateStep2Progress(t){this.step2Progress={...this.step2Progress,...t},await chrome.storage.local.set({[k]:this.step2Progress}),this.step===2&&(this.applyChecklistDOMState(),this.maybeAutoAdvanceFromStep2())}applyChecklistDOMState(){if(!this.container)return;const t=[["hovered",this.step2Progress.hovered],["copied",this.step2Progress.copied],["usedDown",this.step2Progress.usedDown],["usedUp",this.step2Progress.usedUp],["exited",this.step2Progress.exited]];for(const[e,i]of t){const n=this.container.querySelector(`.rl-onb-check-item[data-key="${e}"]`);n==null||n.classList.toggle("completed",i)}}maybeAutoAdvanceFromStep2(){const{hovered:t,copied:e,usedUp:i,usedDown:n,exited:o}=this.step2Progress;t&&e&&i&&n&&o&&this.autoAdvanceTimer===null&&(this.autoAdvanceTimer=window.setTimeout(()=>{this.autoAdvanceTimer=null,this.step===2&&this.setStep(3)},700))}render(){if(this.step===0){this.fadeOutAndUnmount();return}if(this.container&&this.container.classList.contains("visible")){this.beginStepCrossfade();return}this.renderImmediate()}renderImmediate(){this.ensureContainer(),this.container&&(this.swapStepContent(),this.startTracking())}swapStepContent(){this.container&&(this.container.innerHTML=this.renderStepHTML(this.step),this.attachStepListeners(),this.step===2&&(this.applyChecklistDOMState(),this.maybeAutoAdvanceFromStep2()))}beginStepCrossfade(){this.stepTransitionTimer!==null&&(window.clearTimeout(this.stepTransitionTimer),this.stepTransitionTimer=null);const t=this.container;if(!t){this.renderImmediate();return}t.classList.add("step-fading"),this.stepTransitionTimer=window.setTimeout(()=>{this.stepTransitionTimer=null,!(!this.container||this.step===0)&&(this.swapStepContent(),requestAnimationFrame(()=>{requestAnimationFrame(()=>{var e;(e=this.container)==null||e.classList.remove("step-fading")})}))},I.STEP_FADE_MS)}fadeOutAndUnmount(){if(!this.container){this.unmount();return}this.stepTransitionTimer!==null&&(window.clearTimeout(this.stepTransitionTimer),this.stepTransitionTimer=null),this.container.classList.add("step-fading"),this.stepTransitionTimer=window.setTimeout(()=>{this.stepTransitionTimer=null,this.unmount()},I.STEP_FADE_MS)}ensureContainer(){if(this.container)return;this.attachStyles();const t=document.createElement("div");t.id="redline-onboarding-tooltip",t.setAttribute("data-redline-ui","true"),t.setAttribute("role","dialog"),t.setAttribute("aria-live","polite"),document.body.appendChild(t),this.container=t,this.boundHandleResize||(this.boundHandleResize=()=>this.updatePosition(),window.addEventListener("resize",this.boundHandleResize))}attachStyles(){const t="redline-onboarding-styles";if(document.getElementById(t))return;const e=document.createElement("style");e.id=t,e.setAttribute("data-redline-ui","true"),e.textContent=`
      /* Suppress the FAB's per-button hover tooltips while onboarding is
         visible — they otherwise pop up behind the onboarding tooltip and
         create a confusing stacked overlay. :has() scopes this to "only
         while #redline-onboarding-tooltip is in the DOM", so it lifts
         automatically when the tour ends and the container is removed. */
      body:has(#redline-onboarding-tooltip) #redline-floating-button .btn-tooltip {
        display: none !important;
      }

      #redline-onboarding-tooltip {
        position: fixed;
        z-index: 2147483647;
        max-width: 280px;
        min-width: 220px;
        padding: 14px 16px 14px;
        background: #000000;
        color: #ffffff;
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 12px;
        box-shadow:
          0 12px 32px rgba(0, 0, 0, 0.45),
          0 2px 6px rgba(0, 0, 0, 0.3);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 13px;
        line-height: 1.45;
        pointer-events: auto;
        opacity: 0;
        transform: translate(-50%, 3px);
        transition: opacity 0.26s ease-in-out, transform 0.26s ease-in-out;
      }

      #redline-onboarding-tooltip.visible {
        opacity: 1;
        transform: translate(-50%, 0);
      }

      /* Mid-step crossfade: while .step-fading is on, the tooltip drifts
         a couple of px down and fades to invisible. We swap the inner HTML
         while it's invisible, then remove .step-fading so the new step
         eases back in to its anchored position. The motion is intentionally
         small (~3px) and the easing is symmetric ease-in-out so the
         transition reads as a gentle breath rather than a flash. */
      #redline-onboarding-tooltip.visible.step-fading {
        opacity: 0;
        transform: translate(-50%, 3px);
      }

      #redline-onboarding-tooltip::after {
        content: '';
        position: absolute;
        bottom: -7px;
        left: 50%;
        width: 12px;
        height: 12px;
        background: #000000;
        border-right: 1px solid rgba(255, 255, 255, 0.18);
        border-bottom: 1px solid rgba(255, 255, 255, 0.18);
        transform: translateX(-50%) rotate(45deg);
      }

      #redline-onboarding-tooltip .rl-onb-step {
        font-size: 11px;
        font-weight: 500;
        letter-spacing: 0.01em;
        color: #e63946;
        margin-bottom: 6px;
      }

      #redline-onboarding-tooltip .rl-onb-title {
        font-size: 14px;
        font-weight: 600;
        color: #ffffff;
        margin-bottom: 2px;
      }

      #redline-onboarding-tooltip .rl-onb-body {
        font-size: 13px;
        color: rgba(255, 255, 255, 0.78);
        margin-bottom: 0;
      }

      #redline-onboarding-tooltip .rl-onb-checklist {
        list-style: none;
        margin: 12px 0 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        gap: 8px;
      }

      #redline-onboarding-tooltip .rl-onb-check-item {
        display: flex;
        align-items: flex-start;
        gap: 9px;
        font-size: 12.5px;
        line-height: 1.4;
        color: rgba(255, 255, 255, 0.78);
        transition: color 0.18s ease;
      }

      #redline-onboarding-tooltip .rl-onb-check-item.completed {
        color: rgba(255, 255, 255, 0.45);
      }

      #redline-onboarding-tooltip .rl-onb-check-item.completed .rl-onb-check-label {
        text-decoration: line-through;
        text-decoration-color: rgba(255, 255, 255, 0.35);
      }

      #redline-onboarding-tooltip .rl-onb-check-circle {
        flex-shrink: 0;
        width: 16px;
        height: 16px;
        margin-top: 1px;
        border-radius: 50%;
        border: 1.5px solid rgba(255, 255, 255, 0.35);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        color: #ffffff;
        transition: background 0.2s ease, border-color 0.2s ease,
                    transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
      }

      #redline-onboarding-tooltip .rl-onb-check-icon {
        opacity: 0;
        transform: scale(0.6);
        transition: opacity 0.18s ease, transform 0.25s cubic-bezier(0.34, 1.56, 0.64, 1);
      }

      #redline-onboarding-tooltip .rl-onb-check-item.completed .rl-onb-check-circle {
        background: #e63946;
        border-color: #e63946;
        transform: scale(1.05);
      }

      #redline-onboarding-tooltip .rl-onb-check-item.completed .rl-onb-check-icon {
        opacity: 1;
        transform: scale(1);
      }

      #redline-onboarding-tooltip .rl-onb-check-label {
        flex: 1;
        min-width: 0;
      }

      #redline-onboarding-tooltip kbd {
        display: inline-block;
        padding: 1px 5px;
        margin: 0 1px;
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.18);
        border-radius: 4px;
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
        font-size: 11px;
        font-weight: 500;
        color: #ffffff;
        line-height: 1.2;
      }

      #redline-onboarding-tooltip .rl-onb-actions {
        display: flex;
        gap: 8px;
        align-items: center;
        margin-top: 12px;
      }

      #redline-onboarding-tooltip .rl-onb-btn {
        appearance: none;
        font-family: inherit;
        font-size: 12px;
        font-weight: 500;
        line-height: 1.2;
        padding: 7px 12px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        transition: background 0.15s ease, color 0.15s ease;
      }

      #redline-onboarding-tooltip .rl-onb-btn--primary {
        background: #e63946;
        color: #ffffff;
      }

      #redline-onboarding-tooltip .rl-onb-btn--primary:hover {
        background: #d62839;
      }

      #redline-onboarding-tooltip .rl-onb-btn--ghost {
        background: transparent;
        color: rgba(255, 255, 255, 0.65);
      }

      #redline-onboarding-tooltip .rl-onb-btn--ghost:hover {
        color: #ffffff;
      }

      #redline-onboarding-tooltip .rl-onb-btn:focus,
      #redline-onboarding-tooltip .rl-onb-btn:focus-visible {
        outline: 2px solid rgba(230, 57, 70, 0.6);
        outline-offset: 2px;
      }

      #redline-onboarding-tooltip .rl-onb-close {
        position: absolute;
        top: 8px;
        right: 8px;
        width: 22px;
        height: 22px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: transparent;
        color: rgba(255, 255, 255, 0.55);
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
        line-height: 1;
        padding: 0;
      }

      #redline-onboarding-tooltip .rl-onb-close:hover {
        background: rgba(255, 255, 255, 0.08);
        color: #ffffff;
      }
    `,document.head.appendChild(e)}renderStepHTML(t){const e='<button type="button" class="rl-onb-close" data-action="skip" aria-label="Dismiss onboarding">×</button>';switch(t){case 1:return`
          ${e}
          <div class="rl-onb-step">Step 1 of 3</div>
          <div class="rl-onb-title">Click me to activate Redline</div>
          <div class="rl-onb-body">Tap the icon below to turn on inspection mode.</div>
        `;case 2:{const i=`
          <svg class="rl-onb-check-icon" width="11" height="11" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <polyline points="2.5 6.5 5 9 9.5 3.5"/>
          </svg>
        `;return`
          ${e}
          <div class="rl-onb-step">Step 2 of 3</div>
          <div class="rl-onb-title">Try the inspector</div>
          <ul class="rl-onb-checklist">
            <li class="rl-onb-check-item" data-key="hovered">
              <span class="rl-onb-check-circle">${i}</span>
              <span class="rl-onb-check-label">Hover any element to see its layout</span>
            </li>
            <li class="rl-onb-check-item" data-key="copied">
              <span class="rl-onb-check-circle">${i}</span>
              <span class="rl-onb-check-label">Click to copy a div's name</span>
            </li>
            <li class="rl-onb-check-item" data-key="usedDown">
              <span class="rl-onb-check-circle">${i}</span>
              <span class="rl-onb-check-label">Press <kbd>↓</kbd> to select the inner layer</span>
            </li>
            <li class="rl-onb-check-item" data-key="usedUp">
              <span class="rl-onb-check-circle">${i}</span>
              <span class="rl-onb-check-label">Press <kbd>↑</kbd> to select the parent layer</span>
            </li>
            <li class="rl-onb-check-item" data-key="exited">
              <span class="rl-onb-check-circle">${i}</span>
              <span class="rl-onb-check-label">Hit <kbd>Esc</kbd> to exit Redline</span>
            </li>
          </ul>
        `}case 3:return`
          ${e}
          <div class="rl-onb-step">Step 3 of 3</div>
          <div class="rl-onb-title">Set a keyboard shortcut</div>
          <div class="rl-onb-body">
            Quicker access from any tab. We recommend
            <kbd>⌥</kbd><kbd>R</kbd> — bind it on Chrome's shortcuts page,
            then come back here and press it to test.
          </div>
          <div class="rl-onb-actions">
            <button type="button" class="rl-onb-btn rl-onb-btn--primary" data-action="open-shortcuts">Open shortcuts</button>
            <button type="button" class="rl-onb-btn rl-onb-btn--ghost" data-action="skip">Done</button>
          </div>
        `;default:return""}}attachStepListeners(){this.container&&this.container.querySelectorAll("[data-action]").forEach(t=>{const e=t.dataset.action;t.addEventListener("click",i=>{i.preventDefault(),i.stopPropagation(),this.handleAction(e)})})}handleAction(t){var e,i;switch(t){case"next":this.step===2&&this.setStep(3);return;case"open-shortcuts":(i=(e=this.callbacks).onOpenShortcuts)==null||i.call(e);return;case"skip":this.setStep(0);return}}startTracking(){if(this.rafId!==null)return;const t=()=>{this.rafId=null,this.updatePosition(),this.container&&this.step!==0&&(this.rafId=requestAnimationFrame(t))};this.rafId=requestAnimationFrame(t)}stopTracking(){this.rafId!==null&&(cancelAnimationFrame(this.rafId),this.rafId=null)}updatePosition(){if(!this.container)return;const t=document.querySelector("#redline-floating-button .redline-fab"),e=document.getElementById("redline-floating-button"),i=t&&t.offsetParent!==null?t:e;if(!i){this.container.classList.remove("visible");return}const n=i.getBoundingClientRect();if(n.width===0&&n.height===0){this.container.classList.remove("visible");return}const o=n.left+n.width/2,r=14;this.container.style.left=`${o}px`,this.container.style.bottom=`${window.innerHeight-n.top+r}px`,this.container.style.top="auto",this.container.classList.contains("visible")||requestAnimationFrame(()=>{var d;return(d=this.container)==null?void 0:d.classList.add("visible")})}};c(I,"STEP_FADE_MS",240);let K=I;const j="redline-content-script-loaded";if(!document.getElementById(j)){const s=document.createElement("meta");s.id=j,s.setAttribute("data-redline-ui","true"),(document.head||document.documentElement).appendChild(s),Bt()}function Bt(){let s,t=null;function e(){const a=o.getIsActive();s.setRedlineActive(a),i(a),a&&n.notifyInspectorActivated(),chrome.runtime.sendMessage({type:"STATE_CHANGED",isActive:a})}function i(a){t!==a&&(t=a,chrome.storage.local.set({redlineIsActive:a}))}const n=new K({onOpenShortcuts:()=>{chrome.runtime.sendMessage({type:"OPEN_SHORTCUTS_PAGE"})}}),o=new $t({onDeactivate:()=>e(),onHover:()=>n.notifyHover(),onCopy:()=>n.notifyCopy(),onArrowKey:a=>n.notifyArrow(a),onEscape:()=>n.notifyEscape()});s=new W({onToggleRedline:()=>{o.getIsActive()?o.deactivate():o.activate(),e()},onCollapse:a=>{a&&o.getIsActive()&&(o.deactivate(),e())}});const r="redline-floating-button-hidden",d="redline-floating-button-collapsed";s.mount();const l=chrome.storage.local.get({[R]:0,[k]:O}).then(a=>{const h=a[R],u=typeof h=="number"&&h>=0&&h<=3?h:0,m=a[k],b=p(m);n.applyStep2Progress(b),n.applyStep(u)}).catch(a=>{console.error("[Redline] Onboarding hydrate failed:",a)});function p(a){if(!a||typeof a!="object")return{...O};const h=a;return{hovered:h.hovered===!0,copied:h.copied===!0,usedUp:h.usedUp===!0,usedDown:h.usedDown===!0,exited:h.exited===!0}}chrome.storage.local.get({[r]:!1}).then(a=>{a[r]===!0?s.hide():s.show()}),chrome.storage.onChanged.addListener((a,h)=>{if(h==="local"){if(a.redlineIsActive){const u=a.redlineIsActive.newValue===!0;t=u,u&&!o.getIsActive()?(o.activate(),e()):!u&&o.getIsActive()&&(o.deactivate(),e())}if(a[r]&&(a[r].newValue===!0?(o.getIsActive()&&(o.deactivate(),e()),s.hide()):s.show()),a[R]){const u=a[R].newValue,m=typeof u=="number"&&u>=0&&u<=3?u:0;n.applyStep(m)}if(a[k]){const u=p(a[k].newValue);n.applyStep2Progress(u)}a[d]&&!(a[d].newValue===!0)&&s.getIsCollapsed()&&s.expand()}});function f(){s.getIsCollapsed()?(s.expand(),o.getIsActive()||o.activate()):o.getIsActive()?o.deactivate():o.activate(),e(),n.notifyShortcutUsed()}chrome.runtime.onMessage.addListener((a,h,u)=>{switch(a.type){case"TOGGLE_INSPECTION":return Promise.all([l,s.whenReady()]).catch(m=>{console.error("[Redline] Inspector invoke failed to hydrate:",m)}).then(()=>{f(),u({success:!0})}),!0;case"GET_STATE":u({isActive:o.getIsActive()});return}});function g(a){if(a.repeat||!a.shiftKey)return!1;const h=a.metaKey||a.ctrlKey;return!!(a.code==="KeyR"&&a.altKey&&!h||a.code==="KeyL"&&h&&!a.altKey)}document.addEventListener("keydown",a=>{g(a)&&(a.preventDefault(),a.stopPropagation(),Promise.all([l,s.whenReady()]).then(()=>{f()}))},!0)}
