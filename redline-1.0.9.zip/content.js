var A=Object.defineProperty;var I=(u,e,t)=>e in u?A(u,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):u[e]=t;var a=(u,e,t)=>I(u,typeof e!="symbol"?e+"":e,t);const y={background:"#000000",color:"#fff",padding:"6px 10px",borderRadius:"6px",fontSize:"12px",fontWeight:"500",boxShadow:"0 2px 8px rgba(0, 0, 0, 0.3)",fontFamily:"-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"},E={...y,padding:"3px 6px",fontSize:"11px",borderRadius:"3px"},L={...y,padding:"8px 12px",fontSize:"13px"};function O(u="medium"){const e=u==="small"?E:u==="large"?L:y;return`
    background: ${e.background};
    color: ${e.color};
    padding: ${e.padding};
    border-radius: ${e.borderRadius};
    font-family: ${e.fontFamily};
    font-size: ${e.fontSize};
    font-weight: ${e.fontWeight};
    white-space: nowrap;
    pointer-events: none;
    box-shadow: ${e.boxShadow};
  `}class ${constructor(){a(this,"container");a(this,"shadow");a(this,"tooltip");this.container=document.createElement("div"),this.container.id="redline-tooltip-container",this.shadow=this.container.attachShadow({mode:"open"}),this.tooltip=document.createElement("div"),this.tooltip.className="tooltip";const e=document.createElement("style");e.textContent=this.getStyles(),this.shadow.appendChild(e),this.shadow.appendChild(this.tooltip)}getStyles(){return`
      :host {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 2147483646;
      }

      .tooltip {
        position: fixed;
        background: ${y.background};
        color: ${y.color};
        padding: ${y.padding};
        border-radius: ${y.borderRadius};
        font-family: ${y.fontFamily};
        font-size: ${y.fontSize};
        font-weight: ${y.fontWeight};
        white-space: nowrap;
        pointer-events: none;
        box-shadow: ${y.boxShadow};
        display: none;
        z-index: 2147483647;
        line-height: 1.3;
      }

      .tooltip.visible {
        display: block;
      }

      /* Size variants */
      .tooltip.small {
        padding: ${E.padding};
        font-size: ${E.fontSize};
        border-radius: ${E.borderRadius};
      }

      .tooltip.large {
        padding: ${L.padding};
        font-size: ${L.fontSize};
      }

      /* Color variants */
      .tooltip.light {
        background: rgba(255, 255, 255, 0.95);
        color: #1a1a2e;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      }

      .tooltip.accent {
        background: #e63946;
        color: #fff;
      }

      /* Content styling — same metrics as tooltip body so labels aren’t visually smaller than values */
      .tooltip .label {
        font-size: inherit;
        font-weight: inherit;
        color: rgba(255, 255, 255, 0.7);
        margin-right: 4px;
      }

      .tooltip .value {
        font-size: inherit;
        font-weight: inherit;
        color: #fff;
      }

      .tooltip.light .label {
        color: rgba(26, 26, 46, 0.6);
      }

      .tooltip.light .value {
        color: #1a1a2e;
      }
    `}show(e){const{content:t,x:i,y:s,size:n="medium",variant:r="dark",offset:l={}}=e;typeof t=="string"?this.tooltip.textContent=t:(this.tooltip.innerHTML="",this.tooltip.appendChild(t)),this.tooltip.className="tooltip visible",n!=="medium"&&this.tooltip.classList.add(n),r!=="dark"&&this.tooltip.classList.add(r);const d=l.x||0,o=l.y||0;this.tooltip.style.left=`${i+d}px`,this.tooltip.style.top=`${s+o}px`,this.container.parentElement||document.body.appendChild(this.container)}showSmart(e){const{content:t,targetRect:i,preferredPosition:s="top",size:n="medium",variant:r="dark",gap:l=8}=e;typeof t=="string"?this.tooltip.textContent=t:(this.tooltip.innerHTML="",this.tooltip.appendChild(t)),this.tooltip.className="tooltip visible",n!=="medium"&&this.tooltip.classList.add(n),r!=="dark"&&this.tooltip.classList.add(r),this.tooltip.style.visibility="hidden",this.tooltip.style.display="block",this.container.parentElement||document.body.appendChild(this.container);const d=this.tooltip.getBoundingClientRect(),o=window.innerWidth,h=window.innerHeight,c=8;let g,p;switch(s){case"top":p=i.top-d.height-l,p<c&&(p=i.bottom+l),g=i.left+i.width/2-d.width/2;break;case"bottom":p=i.bottom+l,p+d.height>h-c&&(p=i.top-d.height-l),g=i.left+i.width/2-d.width/2;break;case"left":g=i.left-d.width-l,g<c&&(g=i.right+l),p=i.top+i.height/2-d.height/2;break;case"right":g=i.right+l,g+d.width>o-c&&(g=i.left-d.width-l),p=i.top+i.height/2-d.height/2;break}g=Math.max(c,Math.min(g,o-d.width-c)),p=Math.max(c,Math.min(p,h-d.height-c)),this.tooltip.style.left=`${g}px`,this.tooltip.style.top=`${p}px`,this.tooltip.style.visibility=""}updatePosition(e,t){this.tooltip.style.left=`${e}px`,this.tooltip.style.top=`${t}px`}updateContent(e){typeof e=="string"?this.tooltip.textContent=e:(this.tooltip.innerHTML="",this.tooltip.appendChild(e))}hide(){this.tooltip.classList.remove("visible")}isVisible(){return this.tooltip.classList.contains("visible")}destroy(){this.container.parentElement&&this.container.parentElement.removeChild(this.container)}}function M(u){const e=document.createElement("span");return u.forEach((t,i)=>{if(i>0&&e.appendChild(document.createTextNode(" ")),t.label){const n=document.createElement("span");n.className="label",n.textContent=t.label,e.appendChild(n)}const s=document.createElement("span");s.className="value",s.textContent=t.value,e.appendChild(s)}),e}class D{constructor(){a(this,"container");a(this,"shadow");a(this,"box");a(this,"tooltip");a(this,"frozenIndicator");a(this,"marginOverlay");a(this,"borderOverlay");a(this,"paddingOverlay");a(this,"contentOverlay");a(this,"marginLabels");a(this,"paddingLabels");a(this,"childrenContainer");a(this,"highlightColor","#e63946");a(this,"showBoxModel",!1);a(this,"isFrozen",!1);a(this,"MARGIN_COLOR","rgba(255, 155, 120, 0.32)");a(this,"BORDER_COLOR","rgba(255, 212, 120, 0.38)");a(this,"PADDING_COLOR","rgba(120, 200, 140, 0.32)");this.container=document.createElement("div"),this.container.setAttribute("data-redline-overlay","true"),this.container.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100% !important;
      height: 100% !important;
      pointer-events: none !important;
      z-index: 2147483646 !important;
    `,this.shadow=this.container.attachShadow({mode:"closed"});const e=document.createElement("style");e.textContent=this.getStyles(),this.shadow.appendChild(e),this.marginOverlay=document.createElement("div"),this.marginOverlay.className="box-model-layer margin-layer",this.borderOverlay=document.createElement("div"),this.borderOverlay.className="box-model-layer border-layer",this.paddingOverlay=document.createElement("div"),this.paddingOverlay.className="box-model-layer padding-layer",this.contentOverlay=document.createElement("div"),this.contentOverlay.className="box-model-layer content-layer",this.marginLabels=document.createElement("div"),this.marginLabels.className="box-labels margin-labels",this.paddingLabels=document.createElement("div"),this.paddingLabels.className="box-labels padding-labels",this.childrenContainer=document.createElement("div"),this.childrenContainer.className="children-outlines",this.box=document.createElement("div"),this.box.className="redline-box",this.tooltip=new $,this.frozenIndicator=document.createElement("div"),this.frozenIndicator.className="frozen-indicator",this.frozenIndicator.textContent="⌘ Frozen",this.shadow.appendChild(this.marginOverlay),this.shadow.appendChild(this.borderOverlay),this.shadow.appendChild(this.paddingOverlay),this.shadow.appendChild(this.contentOverlay),this.shadow.appendChild(this.marginLabels),this.shadow.appendChild(this.paddingLabels),this.shadow.appendChild(this.childrenContainer),this.shadow.appendChild(this.box),this.shadow.appendChild(this.frozenIndicator)}getStyles(){return`
      .redline-box {
        position: fixed;
        pointer-events: none;
        z-index: 2147483646;
        border: 2px solid ${this.highlightColor};
        border-radius: 2px;
        background: transparent;
        box-sizing: border-box;
        display: none;
      }

      .box-model-layer {
        position: fixed;
        pointer-events: none;
        z-index: 2147483644;
        display: none;
      }

      .margin-layer {
        background: ${this.MARGIN_COLOR};
      }

      .padding-layer {
        background: ${this.PADDING_COLOR};
      }

      .border-layer {
        background: ${this.BORDER_COLOR};
      }

      .content-layer {
        background: transparent;
      }

      .box-labels {
        position: fixed;
        pointer-events: none;
        z-index: 2147483647;
        display: none;
      }

      .box-label {
        position: absolute;
        font-family: -apple-system, BlinkMacSystemFont, 'SF Mono', Monaco, monospace;
        font-size: 10px;
        font-weight: 600;
        padding: 2px 5px;
        border-radius: 3px;
        white-space: nowrap;
      }

      .margin-labels .box-label {
        background: rgba(230, 100, 80, 0.95);
        color: #fff;
      }

      .padding-labels .box-label {
        background: rgba(80, 160, 100, 0.95);
        color: #fff;
      }

      @keyframes redline-shake {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-3px); }
        40% { transform: translateX(3px); }
        60% { transform: translateX(-2px); }
        80% { transform: translateX(2px); }
      }

      .redline-box.shake,
      .box-model-layer.shake,
      .box-labels.shake {
        animation: redline-shake 0.3s ease-in-out;
      }

      /* Frozen state - dashed border to indicate element is locked */
      .redline-box.frozen {
        border-style: dashed;
        border-color: #ffd93d;
      }

      .frozen-indicator {
        position: fixed;
        background: #ffd93d;
        color: #1a1a2e;
        padding: 4px 8px;
        border-radius: 4px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        z-index: 2147483647;
        pointer-events: none;
        display: none;
      }

      .frozen-indicator.visible {
        display: block;
      }
    `}mount(){this.container.parentElement||document.body.appendChild(this.container),this.tooltip||(this.tooltip=new $)}unmount(){this.tooltip.destroy(),this.tooltip=null,this.container.remove()}highlight(e,t){this.showBoxModel=!0;const i=e.getBoundingClientRect();this.box.style.top=`${i.top}px`,this.box.style.left=`${i.left}px`,this.box.style.width=`${i.width}px`,this.box.style.height=`${i.height}px`,this.box.style.display="block",this.showBoxModelOverlay(e,i),this.updateTooltip(e,i,t)}getBoxModelValues(e){const t=window.getComputedStyle(e),i=s=>parseFloat(s)||0;return{margin:{top:i(t.marginTop),right:i(t.marginRight),bottom:i(t.marginBottom),left:i(t.marginLeft)},border:{top:i(t.borderTopWidth),right:i(t.borderRightWidth),bottom:i(t.borderBottomWidth),left:i(t.borderLeftWidth)},padding:{top:i(t.paddingTop),right:i(t.paddingRight),bottom:i(t.paddingBottom),left:i(t.paddingLeft)}}}showBoxModelOverlay(e,t){const i=this.getBoxModelValues(e);if(i.margin.top>0||i.margin.right>0||i.margin.bottom>0||i.margin.left>0){const l=t.top-i.margin.top,d=t.left-i.margin.left,o=t.width+i.margin.left+i.margin.right,h=t.height+i.margin.top+i.margin.bottom,c=i.margin.top,g=i.margin.left,p=o-i.margin.right,f=h-i.margin.bottom;this.marginOverlay.style.top=`${l}px`,this.marginOverlay.style.left=`${d}px`,this.marginOverlay.style.width=`${o}px`,this.marginOverlay.style.height=`${h}px`,this.marginOverlay.style.clipPath=`polygon(
        0 0, 100% 0, 100% 100%, 0 100%, 0 0,
        ${g}px ${c}px,
        ${g}px ${f}px,
        ${p}px ${f}px,
        ${p}px ${c}px,
        ${g}px ${c}px
      )`,this.marginOverlay.style.display="block"}else this.marginOverlay.style.display="none";const n=i.padding.top>0||i.padding.right>0||i.padding.bottom>0||i.padding.left>0;if(i.border.top>0||i.border.right>0||i.border.bottom>0||i.border.left>0){const l=t.width,d=t.height,o=i.border.left,h=i.border.top,c=i.border.right,g=i.border.bottom,p=l-o-c,f=d-h-g;if(p>0&&f>0){this.borderOverlay.style.top=`${t.top}px`,this.borderOverlay.style.left=`${t.left}px`,this.borderOverlay.style.width=`${l}px`,this.borderOverlay.style.height=`${d}px`;const b=o,v=h,w=b+p,x=v+f;this.borderOverlay.style.clipPath=`polygon(
          0 0, 100% 0, 100% 100%, 0 100%, 0 0,
          ${b}px ${v}px,
          ${b}px ${x}px,
          ${w}px ${x}px,
          ${w}px ${v}px,
          ${b}px ${v}px
        )`,this.borderOverlay.style.display="block"}else this.borderOverlay.style.display="none"}else this.borderOverlay.style.display="none";if(n){const l=t.top+i.border.top,d=t.left+i.border.left,o=t.width-i.border.left-i.border.right,h=t.height-i.border.top-i.border.bottom,c=i.padding.top,g=i.padding.left,p=o-i.padding.right,f=h-i.padding.bottom;this.paddingOverlay.style.top=`${l}px`,this.paddingOverlay.style.left=`${d}px`,this.paddingOverlay.style.width=`${o}px`,this.paddingOverlay.style.height=`${h}px`,this.paddingOverlay.style.clipPath=`polygon(
        0 0, 100% 0, 100% 100%, 0 100%, 0 0,
        ${g}px ${c}px,
        ${g}px ${f}px,
        ${p}px ${f}px,
        ${p}px ${c}px,
        ${g}px ${c}px
      )`,this.paddingOverlay.style.display="block"}else this.paddingOverlay.style.display="none";this.contentOverlay.style.display="none",this.updateBoxModelLabels(t,i)}updateBoxModelLabels(e,t){if(t.margin.top>0||t.margin.right>0||t.margin.bottom>0||t.margin.left>0){this.marginLabels.innerHTML="",this.marginLabels.style.display="block";const n=e.top-t.margin.top,r=e.left-t.margin.left,l=e.width+t.margin.left+t.margin.right,d=e.height+t.margin.top+t.margin.bottom;if(t.margin.top>0){const o=this.createLabel(Math.round(t.margin.top));o.style.top=`${n+t.margin.top/2-8}px`,o.style.left=`${r+l/2-12}px`,this.marginLabels.appendChild(o)}if(t.margin.bottom>0){const o=this.createLabel(Math.round(t.margin.bottom));o.style.top=`${e.bottom+t.margin.bottom/2-8}px`,o.style.left=`${r+l/2-12}px`,this.marginLabels.appendChild(o)}if(t.margin.left>0){const o=this.createLabel(Math.round(t.margin.left));o.style.top=`${n+d/2-8}px`,o.style.left=`${r+t.margin.left/2-12}px`,this.marginLabels.appendChild(o)}if(t.margin.right>0){const o=this.createLabel(Math.round(t.margin.right));o.style.top=`${n+d/2-8}px`,o.style.left=`${e.right+t.margin.right/2-12}px`,this.marginLabels.appendChild(o)}}else this.marginLabels.style.display="none";if(t.padding.top>0||t.padding.right>0||t.padding.bottom>0||t.padding.left>0){this.paddingLabels.innerHTML="",this.paddingLabels.style.display="block";const n=e.left+t.border.left,r=e.top+t.border.top,l=e.width-t.border.left-t.border.right,d=e.height-t.border.top-t.border.bottom;if(t.padding.top>0){const o=this.createLabel(Math.round(t.padding.top),!0);o.style.top=`${r+t.padding.top/2-8}px`,o.style.left=`${n+l/2-12}px`,this.paddingLabels.appendChild(o)}if(t.padding.bottom>0){const o=this.createLabel(Math.round(t.padding.bottom),!0),h=r+d;o.style.top=`${h-t.padding.bottom/2-8}px`,o.style.left=`${n+l/2-12}px`,this.paddingLabels.appendChild(o)}if(t.padding.left>0){const o=this.createLabel(Math.round(t.padding.left),!0);o.style.top=`${r+d/2-8}px`,o.style.left=`${n+t.padding.left/2-12}px`,this.paddingLabels.appendChild(o)}if(t.padding.right>0){const o=this.createLabel(Math.round(t.padding.right),!0),h=n+l;o.style.top=`${r+d/2-8}px`,o.style.left=`${h-t.padding.right/2-12}px`,this.paddingLabels.appendChild(o)}}else this.paddingLabels.style.display="none"}createLabel(e,t=!1){const i=document.createElement("span");return i.className="box-label",i.textContent=`${e}`,i}hideBoxModelOverlay(){this.marginOverlay.style.display="none",this.marginOverlay.style.clipPath="none",this.borderOverlay.style.display="none",this.borderOverlay.style.clipPath="none",this.paddingOverlay.style.display="none",this.paddingOverlay.style.clipPath="none",this.contentOverlay.style.display="none",this.marginLabels.style.display="none",this.paddingLabels.style.display="none"}parseGap(e){if(!e||e==="normal")return 0;const t=parseFloat(e);return!isFinite(t)||t<=0?0:Math.round(t)}isFlexOrGridDisplay(e){return/(^|\s)(inline-)?(flex|grid)(\s|$)/.test(e)}formatGap(e,t){return e===t?`${e}px`:`${e}px / ${t}px`}computeGapForTooltip(e,t){if(this.isFlexOrGridDisplay(t.display)){const s=this.parseGap(t.rowGap),n=this.parseGap(t.columnGap);if(s>0||n>0)return{label:"gap:",value:this.formatGap(s,n)}}const i=e.parentElement;if(i){const s=window.getComputedStyle(i);if(this.isFlexOrGridDisplay(s.display)){const n=this.parseGap(s.rowGap),r=this.parseGap(s.columnGap);if(n>0||r>0)return{label:"parent gap:",value:this.formatGap(n,r)}}}return null}truncateFontFamilyForTooltip(e,t=44){var n;const i=((n=e.split(",")[0])==null?void 0:n.trim())??e,s=i.startsWith('"')&&i.endsWith('"')||i.startsWith("'")&&i.endsWith("'")?i.slice(1,-1):i;return s.length<=t?s:s.slice(0,Math.max(1,t-1))+"…"}updateTooltip(e,t,i){const s=e.tagName.toLowerCase(),n=e.id?`#${e.id}`:"",r=Array.from(e.classList).slice(0,3).map(v=>`.${v}`).join(""),l=Math.round(t.width),d=Math.round(t.height);let o=`<${s}>`;n&&(o+=n),r&&(o+=r);const h=[{value:o},{value:`${l} × ${d}`}],c=i==null?void 0:i.typography;c&&(h.push({label:"font-size:",value:c.fontSize}),h.push({label:"font:",value:this.truncateFontFamilyForTooltip(c.fontFamily)}),c.lineHeight&&c.lineHeight!=="normal"&&h.push({label:"lh:",value:c.lineHeight}));const g=window.getComputedStyle(e),p=this.computeGapForTooltip(e,g);p&&h.push(p);const f=M(h);let b=t;if(this.showBoxModel){const v=parseFloat(g.marginTop)||0,w=parseFloat(g.marginBottom)||0,x=parseFloat(g.marginLeft)||0,T=parseFloat(g.marginRight)||0;b=new DOMRect(t.left-x,t.top-v,t.width+x+T,t.height+v+w)}this.tooltip.showSmart({content:f,targetRect:b,preferredPosition:"top",size:"medium",variant:"dark"})}hide(){this.box.style.display="none",this.tooltip.hide(),this.frozenIndicator.classList.remove("visible"),this.box.classList.remove("frozen"),this.hideBoxModelOverlay(),this.clearChildrenHighlight()}highlightChildren(e){this.clearChildrenHighlight();for(const t of e){const i=t.getBoundingClientRect();if(i.width===0||i.height===0)continue;const s=document.createElement("div");s.className="child-outline",s.style.cssText=`
        position: fixed;
        top: ${i.top}px;
        left: ${i.left}px;
        width: ${i.width}px;
        height: ${i.height}px;
        border: 1.5px dashed ${this.highlightColor};
        background: rgba(230, 57, 70, 0.08);
        pointer-events: none;
        box-sizing: border-box;
        z-index: 2147483645;
      `,this.childrenContainer.appendChild(s)}}clearChildrenHighlight(){this.childrenContainer.innerHTML=""}setColor(e){this.highlightColor=e,this.box.style.borderColor=e}shake(){const e=[this.box,this.marginOverlay,this.borderOverlay,this.paddingOverlay,this.marginLabels,this.paddingLabels];e.forEach(t=>{t.classList.remove("shake"),t.offsetWidth,t.classList.add("shake")}),setTimeout(()=>{e.forEach(t=>t.classList.remove("shake"))},300)}setFrozen(e){if(this.isFrozen!==e)if(this.isFrozen=e,e){this.box.classList.add("frozen"),this.frozenIndicator.classList.add("visible");const t=parseFloat(this.box.style.top)||0,i=parseFloat(this.box.style.left)||0,s=parseFloat(this.box.style.width)||0;this.frozenIndicator.style.top=`${t-24}px`,this.frozenIndicator.style.left=`${i+s-60}px`;const n=window.innerWidth,r=parseFloat(this.frozenIndicator.style.left);r+60>n&&(this.frozenIndicator.style.left=`${n-68}px`),r<8&&(this.frozenIndicator.style.left="8px"),t<32&&(this.frozenIndicator.style.top=`${t+parseFloat(this.box.style.height)+8}px`)}else this.box.classList.remove("frozen"),this.frozenIndicator.classList.remove("visible")}}class N{constructor(){a(this,"elementStack",[]);a(this,"currentIndex",0);a(this,"currentElement",null)}isNavigable(e){return!(!e||e.nodeType!==1||e===document.documentElement||e===document.body||e.hasAttribute("data-redline-overlay")||e.hasAttribute("data-redline-panel")||e.hasAttribute("data-redline-ui")||e.hasAttribute("data-redline-badges")||e.closest("[data-redline-overlay]")||e.closest("[data-redline-panel]")||e.closest("[data-redline-ui]")||e.closest("[data-redline-badges]")||!this.isElementVisible(e))}isElementVisible(e){var r;const t=window.getComputedStyle(e);if(t.visibility==="hidden"||t.visibility==="collapse"||parseFloat(t.opacity)===0)return!1;const s=e.getBoundingClientRect();if(s.width===0||s.height===0)return!1;const n=t.clipPath;if(n&&n!=="none"&&(n==="inset(100%)"||n==="inset(50%)"||n==="polygon(0 0, 0 0, 0 0, 0 0)"||n==="circle(0)"||n==="circle(0px)"||n==="circle(0px at 50% 50%)"))return!1;if(t.overflow==="hidden"){const l=s.width-parseFloat(t.paddingLeft)-parseFloat(t.paddingRight),d=s.height-parseFloat(t.paddingTop)-parseFloat(t.paddingBottom);if(l<=0&&d<=0&&e.children.length===0&&((r=e.textContent)==null?void 0:r.trim())==="")return!1}return!0}updateAtPoint(e,t){const i=document.elementsFromPoint(e,t);this.elementStack=i.filter(s=>!(s.hasAttribute("data-redline-overlay")||s.hasAttribute("data-redline-panel")||s.hasAttribute("data-redline-ui")||s.hasAttribute("data-redline-badges")||s.closest("[data-redline-overlay]")||s.closest("[data-redline-panel]")||s.closest("[data-redline-ui]")||s.closest("[data-redline-badges]")||s.tagName==="HTML"||s.tagName==="BODY"||!this.isElementVisible(s))),this.currentIndex=0,this.currentElement=this.elementStack[0]??null}navigateUp(){if(!this.currentElement)return null;let e=this.currentElement.parentElement;for(;e&&!this.isNavigable(e);)e=e.parentElement;if(e){this.currentElement=e;const t=this.elementStack.indexOf(e);t>=0&&(this.currentIndex=t)}return this.currentElement}navigateDown(){if(!this.currentElement)return null;const t=Array.from(this.currentElement.children).find(i=>this.isNavigable(i));if(t){this.currentElement=t;const i=this.elementStack.indexOf(t);i>=0&&(this.currentIndex=i)}return this.currentElement}getChildren(){return this.currentElement?Array.from(this.currentElement.children).filter(e=>this.isNavigable(e)):[]}navigateNext(){if(!this.currentElement)return null;let e=this.currentElement.nextElementSibling;for(;e&&!this.isNavigable(e);)e=e.nextElementSibling;return e&&(this.currentElement=e),this.currentElement}navigatePrevious(){if(!this.currentElement)return null;let e=this.currentElement.previousElementSibling;for(;e&&!this.isNavigable(e);)e=e.previousElementSibling;return e&&(this.currentElement=e),this.currentElement}jumpTo(e){return e>=0&&e<this.elementStack.length&&(this.currentIndex=e),this.getCurrentElement()}getCurrentElement(){return this.currentElement??this.elementStack[this.currentIndex]??null}getCurrentIndex(){return this.currentIndex}getStackSize(){return this.elementStack.length}getStack(){return[...this.elementStack]}getBreadcrumbPath(){const e=this.getCurrentElement();if(!e)return[];const t=[];let i=e;for(;i&&i!==document.documentElement;)t.unshift({tagName:i.tagName.toLowerCase(),id:i.id||null,classes:Array.from(i.classList).slice(0,2),selector:this.getSimpleSelector(i)}),i=i.parentElement;return t}getSimpleSelector(e){const t=e.tagName.toLowerCase();if(e.id)return`${t}#${e.id}`;const i=Array.from(e.classList).slice(0,2);return i.length>0?`${t}.${i.join(".")}`:t}canNavigateUp(){return this.currentIndex<this.elementStack.length-1}canNavigateDown(){return this.currentIndex>0}reset(){this.elementStack=[],this.currentIndex=0,this.currentElement=null}getLayerIndicator(){return this.elementStack.length===0?"":`${this.currentIndex+1} / ${this.elementStack.length}`}}const C=class C{extractLayoutStyles(e){const t=window.getComputedStyle(e),i={};for(const s of C.LAYOUT_PROPERTIES){const n=s.replace(/([A-Z])/g,"-$1").toLowerCase(),r=t.getPropertyValue(n);r&&r!=="none"&&r!=="normal"&&r!=="auto"?i[s]=r:["display","position","overflow","width","height"].includes(s)&&(i[s]=r||"auto")}return i}elementHasRenderableText(e){var i,s,n;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement)return e.value.trim().length>0||(((i=e.placeholder)==null?void 0:i.trim().length)??0)>0;if(e instanceof HTMLSelectElement){const r=e.selectedOptions[0];return(((s=r==null?void 0:r.text)==null?void 0:s.trim())??"").length>0}if(e.namespaceURI==="http://www.w3.org/2000/svg"){const r=e.tagName.toLowerCase();return r==="text"||r==="tspan"?(((n=e.textContent)==null?void 0:n.trim().length)??0)>0:!1}const t=e;return typeof t.innerText!="string"?!1:t.innerText.trim().length>0}extractTypographyStyles(e){if(!this.elementHasRenderableText(e))return null;const t=window.getComputedStyle(e);return{fontSize:t.fontSize,fontFamily:t.fontFamily,lineHeight:t.lineHeight}}analyzeHeightChain(e){const t=[];let i=e;for(;i&&i!==document.documentElement;){const s=window.getComputedStyle(i),n=s.height,r=this.hasExplicitHeight(i,s);t.push({tagName:i.tagName.toLowerCase(),selector:this.getSimpleSelector(i),height:n,hasExplicitHeight:r,overflow:s.overflow,isFlexChild:this.isFlexChild(i),isGridChild:this.isGridChild(i)}),i=i.parentElement}return t}hasExplicitHeight(e,t){var s;const i=t.height;if(i.includes("vh")||i.includes("%"))return!0;if(i.endsWith("px")){const n=parseFloat(i),r=(s=e.style)==null?void 0:s.height;if(r&&r!=="auto")return!0;const l=t.minHeight,d=t.maxHeight;if(l!=="0px"&&l!=="auto"||d!=="none"&&d!=="auto")return!0;if(this.isFlexChild(e)){const o=t.flexGrow;if(o&&parseFloat(o)>0)return!0}if(n>=100)return!0}return!1}isFlexChild(e){const t=e.parentElement;if(!t)return!1;const i=window.getComputedStyle(t).display;return i==="flex"||i==="inline-flex"}isGridChild(e){const t=e.parentElement;if(!t)return!1;const i=window.getComputedStyle(t).display;return i==="grid"||i==="inline-grid"}getParentContainerInfo(e){const t=e.parentElement;if(!t||t===document.body)return null;const i=window.getComputedStyle(t),s=i.display;if(!["flex","inline-flex","grid","inline-grid"].includes(s))return null;const n={selector:this.getSimpleSelector(t),tagName:t.tagName.toLowerCase(),display:s,overflow:i.overflow,hasExplicitHeight:this.hasExplicitHeight(t,i)};return s.includes("flex")&&(n.flexDirection=i.flexDirection,n.alignItems=i.alignItems,n.justifyContent=i.justifyContent),s.includes("grid")&&(n.gridTemplateColumns=i.gridTemplateColumns,n.gridTemplateRows=i.gridTemplateRows),n}identifyIssues(e,t,i){const s=[];return(t.overflow==="hidden"||t.overflowY==="hidden")&&s.push("overflow: hidden may clip content"),t.height==="auto"&&(i.some(r=>r.hasExplicitHeight)||s.push("No ancestor with explicit height - element cannot fill available space")),this.isFlexChild(e)&&window.getComputedStyle(e).flexGrow==="0"&&s.push("Flex child with flex-grow: 0 - will not expand to fill space"),s}getSimpleSelector(e){const t=e.tagName.toLowerCase();if(e.id)return`${t}#${e.id}`;const i=Array.from(e.classList).slice(0,2);return i.length>0?`${t}.${i.join(".")}`:t}};a(C,"LAYOUT_PROPERTIES",["display","position","width","height","minWidth","minHeight","maxWidth","maxHeight","boxSizing","margin","padding","overflow","overflowX","overflowY","flexDirection","flexWrap","justifyContent","alignItems","alignSelf","flexGrow","flexShrink","flexBasis","gridTemplateColumns","gridTemplateRows","gridColumn","gridRow","gap"]);let S=C;class B{constructor(e={},t){a(this,"container");a(this,"shadow");a(this,"highlightBox");a(this,"linesContainer");a(this,"labelsContainer");a(this,"callbacks");a(this,"enableRulerInteraction");a(this,"showElementHighlightFrame");a(this,"guideColor","#e63946");a(this,"MAX_ELEMENTS",100);a(this,"LINE_CACHE_TTL",120);a(this,"lineElementsCache",new Map);a(this,"rulerLines",[]);a(this,"selectedLine",null);a(this,"hoveredLine",null);a(this,"isShowingElementPreviews",!1);a(this,"isShiftPressed",!1);a(this,"isHybridMode",!1);a(this,"currentElement",null);a(this,"boundHandleKeyDown",null);a(this,"boundHandleKeyUp",null);this.callbacks=e,this.enableRulerInteraction=(t==null?void 0:t.enableRulerInteraction)??!0,this.showElementHighlightFrame=(t==null?void 0:t.showElementHighlightFrame)??!0,this.container=document.createElement("div"),this.container.setAttribute("data-redline-guides","true"),this.container.style.cssText=`
      position: fixed !important;
      top: 0 !important;
      left: 0 !important;
      width: 100% !important;
      height: 100% !important;
      pointer-events: none !important;
      z-index: 2147483645 !important;
    `,this.shadow=this.container.attachShadow({mode:"closed"});const i=document.createElement("style");i.textContent=this.getStyles(),this.shadow.appendChild(i),this.highlightBox=document.createElement("div"),this.highlightBox.className="highlight-box",this.linesContainer=document.createElement("div"),this.linesContainer.className=this.enableRulerInteraction?"guides-lines":"guides-lines guides-lines--passive",this.labelsContainer=document.createElement("div"),this.labelsContainer.className="guides-labels",this.shadow.appendChild(this.highlightBox),this.shadow.appendChild(this.linesContainer),this.shadow.appendChild(this.labelsContainer)}getStyles(){return`
      .highlight-box {
        position: fixed;
        pointer-events: none;
        border: 2px solid ${this.guideColor};
        box-sizing: border-box;
        display: none;
        z-index: 3;
      }

      .guides-lines {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 1;
      }

      .guides-lines--passive .guide-line {
        pointer-events: none !important;
        cursor: default !important;
      }

      @keyframes redline-guides-shake {
        0%, 100% { transform: translateX(0); }
        20% { transform: translateX(-4px); }
        40% { transform: translateX(4px); }
        60% { transform: translateX(-3px); }
        80% { transform: translateX(3px); }
      }

      .highlight-box.shake {
        animation: redline-guides-shake 0.3s ease-in-out;
      }

      .guides-labels {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        pointer-events: none;
        z-index: 2;
      }

      /* Guide lines with larger hit area using padding */
      .guide-line {
        position: fixed;
        background: ${this.guideColor};
        pointer-events: auto;
        opacity: 0.4;
        cursor: pointer;
        transition: opacity 0.15s;
        box-sizing: content-box;
        background-clip: content-box;
      }

      .guide-line:hover {
        opacity: 0.9;
      }

      .guide-line.hovered {
        opacity: 0.7;
      }

      .guide-line.selected {
        opacity: 1;
      }

      /* In hybrid mode, don't show hover effects by default */
      .guide-line.hybrid-mode {
        cursor: default;
        pointer-events: auto;
      }

      .guide-line.hybrid-mode:hover {
        opacity: 0.9;
        cursor: pointer;
      }

      .guide-line.hybrid-mode.hovered {
        opacity: 0.7;
        cursor: pointer;
      }

      .guide-line.hybrid-mode.hovered:hover {
        opacity: 0.9;
      }

      /* Horizontal lines: 1px tall with 6px padding top/bottom for hit area */
      .guide-line-horizontal {
        height: 1px;
        width: 100vw;
        left: 0;
        padding: 6px 0;
        margin-top: -6px;
      }

      .guide-line-horizontal:hover,
      .guide-line-horizontal.selected {
        height: 2px;
        margin-top: -6px;
      }

      /* Vertical lines: 1px wide with 6px padding left/right for hit area */
      .guide-line-vertical {
        width: 1px;
        height: 100vh;
        top: 0;
        padding: 0 6px;
        margin-left: -6px;
      }

      .guide-line-vertical:hover,
      .guide-line-vertical.selected {
        width: 2px;
        margin-left: -6px;
      }

      .guide-line-center {
        opacity: 0.25;
      }

      .guide-line-center:hover {
        opacity: 0.6;
      }

      .guide-line-center.hovered {
        opacity: 0.6;
      }

      /* In hybrid mode, center lines don't show hover by default */
      .guide-line-center.hybrid-mode:hover {
        opacity: 0.6;
      }

      .guide-line-center.hybrid-mode.hovered {
        opacity: 0.6;
      }

      .guide-line-center.hybrid-mode.hovered:hover {
        opacity: 0.6;
      }

      /* Preview highlight (on hover) - dashed border */
      .element-highlight-preview {
        position: fixed;
        border: 2px dashed ${this.guideColor};
        box-sizing: border-box;
        pointer-events: none;
        opacity: 0.4;
        z-index: 4;
        background: rgba(230, 57, 70, 0.05);
      }

      /* Selected highlight (on click) - solid border */
      .element-highlight {
        position: fixed;
        border: 2px solid ${this.guideColor};
        box-sizing: border-box;
        pointer-events: none;
        opacity: 0.6;
        z-index: 4;
        background: rgba(230, 57, 70, 0.1);
      }
    `}mount(){this.container.parentElement||(document.body.appendChild(this.container),this.boundHandleKeyDown=this.handleKeyDown.bind(this),this.boundHandleKeyUp=this.handleKeyUp.bind(this),document.addEventListener("keydown",this.boundHandleKeyDown,!0),document.addEventListener("keyup",this.boundHandleKeyUp,!0))}unmount(){this.container.remove(),this.boundHandleKeyDown&&(document.removeEventListener("keydown",this.boundHandleKeyDown,!0),this.boundHandleKeyDown=null),this.boundHandleKeyUp&&(document.removeEventListener("keyup",this.boundHandleKeyUp,!0),this.boundHandleKeyUp=null)}showGuides(e){this.currentElement=e,this.linesContainer.innerHTML="",this.labelsContainer.innerHTML="",this.rulerLines=[],this.hoveredLine=null;const t=e.getBoundingClientRect();this.showElementHighlightFrame?(this.highlightBox.style.top=`${t.top}px`,this.highlightBox.style.left=`${t.left}px`,this.highlightBox.style.width=`${t.width}px`,this.highlightBox.style.height=`${t.height}px`,this.highlightBox.style.display="block"):this.highlightBox.style.display="none",(!this.isHybridMode||this.isShiftPressed)&&this.drawRulerLines(t)}hide(){this.highlightBox.style.display="none",this.linesContainer.innerHTML="",this.labelsContainer.innerHTML="",this.rulerLines=[],this.selectedLine=null,this.hoveredLine=null,this.currentElement=null}shake(){this.highlightBox.style.display!=="none"&&(this.highlightBox.classList.remove("shake"),this.highlightBox.offsetWidth,this.highlightBox.classList.add("shake"),window.setTimeout(()=>this.highlightBox.classList.remove("shake"),320))}getSelectedLine(){return this.selectedLine}setHybridMode(e){this.isHybridMode=e,this.rulerLines.forEach(t=>{e?t.lineElement.classList.add("hybrid-mode"):t.lineElement.classList.remove("hybrid-mode")})}clearSelection(){this.selectedLine&&(this.selectedLine.lineElement.classList.remove("selected"),this.selectedLine=null),this.shadow.querySelectorAll(".element-highlight").forEach(t=>t.remove())}clearHoverHighlights(){this.hoveredLine&&(this.hoveredLine.lineElement.classList.remove("hovered"),this.hoveredLine=null),this.clearElementPreviews()}clearElementPreviews(){this.shadow.querySelectorAll(".element-highlight-preview").forEach(t=>t.remove())}handleKeyDown(e){if(e.key==="Shift"&&!this.isShiftPressed){if(this.isShiftPressed=!0,this.isHybridMode&&this.currentElement){this.showGuides(this.currentElement);return}!this.isHybridMode&&this.hoveredLine&&!this.selectedLine&&this.showElementPreviews(this.hoveredLine)}}handleKeyUp(e){if(e.key==="Shift"&&this.isShiftPressed){if(this.isShiftPressed=!1,this.isHybridMode&&this.currentElement){this.showGuides(this.currentElement);return}!this.isHybridMode&&this.hoveredLine&&!this.selectedLine&&this.hideElementPreviews()}}showElementPreviews(e){this.isShowingElementPreviews||(e.elements=this.getElementsIntersectingLine(e.orientation,e.position),this.isShowingElementPreviews=!0,e.elements.forEach(t=>{this.highlightElementPreview(t)}))}hideElementPreviews(){this.isShowingElementPreviews&&(this.clearElementPreviews(),this.isShowingElementPreviews=!1)}drawRulerLines(e){const t=e.left+e.width/2,i=e.top+e.height/2;this.createInteractiveLine("horizontal",e.top,"top"),this.createInteractiveLine("horizontal",e.bottom,"bottom"),this.createInteractiveLine("vertical",e.left,"left"),this.createInteractiveLine("vertical",e.right,"right"),this.createInteractiveLine("vertical",t,"centerX","center"),this.createInteractiveLine("horizontal",i,"centerY","center")}getLineCacheKey(e,t){const i=Math.round(t);return[e,i,window.innerWidth,window.innerHeight,window.scrollX,window.scrollY].join(":")}getElementsIntersectingLine(e,t){const i=this.getLineCacheKey(e,t),s=this.lineElementsCache.get(i);if(s&&Date.now()-s.timestamp<this.LINE_CACHE_TTL)return s.elements;const n=new Set,r=window.innerWidth,l=window.innerHeight,h=Math.max(20,Math.ceil((e==="horizontal"?r:l)/120));if(e==="horizontal")for(let p=0;p<r;p+=h){const f=document.elementsFromPoint(p,t);for(const b of f)this.isValidElement(b)&&n.add(b)}else for(let p=0;p<l;p+=h){const f=document.elementsFromPoint(t,p);for(const b of f)this.isValidElement(b)&&n.add(b)}const c=Array.from(n);c.sort((p,f)=>{const b=this.getElementDepth(p);return this.getElementDepth(f)-b});const g=c.slice(0,this.MAX_ELEMENTS);return this.lineElementsCache.size>50&&this.lineElementsCache.clear(),this.lineElementsCache.set(i,{timestamp:Date.now(),elements:g}),g}isValidElement(e){if(e.hasAttribute("data-redline-overlay")||e.hasAttribute("data-redline-panel")||e.hasAttribute("data-redline-guides")||e.hasAttribute("data-redline-ui")||e.hasAttribute("data-redline-badges"))return!1;const t=e.tagName.toUpperCase();if(t==="HTML"||t==="BODY"||t==="SCRIPT"||t==="STYLE")return!1;const i=e.getBoundingClientRect();return!(i.width===0||i.height===0)}getElementDepth(e){let t=0,i=e;for(;i&&i!==document.documentElement;)t++,i=i.parentElement;return t}createInteractiveLine(e,t,i,s="edge"){const n=document.createElement("div");n.className=`guide-line guide-line-${e}`,s==="center"&&n.classList.add("guide-line-center"),this.isHybridMode&&n.classList.add("hybrid-mode"),e==="horizontal"?n.style.top=`${t}px`:n.style.left=`${t}px`;const r=this.getElementsIntersectingLine(e,t),l={orientation:e,position:t,type:i,elements:r,lineElement:n};return this.rulerLines.push(l),this.enableRulerInteraction&&(n.addEventListener("mouseenter",()=>{this.handleLineHover(l)}),n.addEventListener("mouseleave",()=>{this.handleLineHover(null)}),n.addEventListener("click",d=>{d.stopPropagation(),this.handleLineClick(l,{x:d.clientX,y:d.clientY})})),this.linesContainer.appendChild(n),n}handleLineHover(e){this.selectedLine||this.isHybridMode&&!this.isShiftPressed||(this.clearHoverHighlights(),this.isShowingElementPreviews=!1,e&&(this.hoveredLine=e,e.lineElement.classList.add("hovered"),this.isShiftPressed&&!this.isHybridMode&&this.showElementPreviews(e)),this.callbacks.onLineHover&&this.callbacks.onLineHover(e))}handleLineClick(e,t){this.clearSelection(),this.clearHoverHighlights(),e.elements=this.getElementsIntersectingLine(e.orientation,e.position),this.selectedLine=e,e.lineElement.classList.add("selected"),e.elements.forEach(i=>{this.highlightElement(i)}),this.callbacks.onLineClick&&this.callbacks.onLineClick(e,t)}highlightElementPreview(e){const t=e.getBoundingClientRect(),i=document.createElement("div");i.className="element-highlight-preview",i.style.top=`${t.top}px`,i.style.left=`${t.left}px`,i.style.width=`${t.width}px`,i.style.height=`${t.height}px`,this.labelsContainer.appendChild(i)}highlightElement(e){const t=e.getBoundingClientRect(),i=document.createElement("div");i.className="element-highlight",i.style.top=`${t.top}px`,i.style.left=`${t.left}px`,i.style.width=`${t.width}px`,i.style.height=`${t.height}px`,this.labelsContainer.appendChild(i)}}class R{constructor(e={}){a(this,"isActive",!1);a(this,"callbacks");a(this,"alignmentGuides");a(this,"highlightOverlay");a(this,"styleAnalyzer");a(this,"layerNavigator");a(this,"currentElement",null);a(this,"childrenDepth",0);a(this,"boundHandleMouseMove");a(this,"boundHandleKeyDown");a(this,"boundHandleScroll");this.callbacks=e,this.layerNavigator=new N,this.styleAnalyzer=new S,this.highlightOverlay=new D,this.alignmentGuides=new B({},{enableRulerInteraction:!1,showElementHighlightFrame:!1}),this.boundHandleMouseMove=this.handleMouseMove.bind(this),this.boundHandleKeyDown=this.handleKeyDown.bind(this),this.boundHandleScroll=this.handleScroll.bind(this)}activate(){this.isActive||(this.isActive=!0,this.alignmentGuides.mount(),this.highlightOverlay.mount(),document.addEventListener("mousemove",this.boundHandleMouseMove,!0),document.addEventListener("keydown",this.boundHandleKeyDown,!0),window.addEventListener("scroll",this.boundHandleScroll,!0),document.body.style.cursor="crosshair")}deactivate(){var e,t;this.isActive&&(this.isActive=!1,document.removeEventListener("mousemove",this.boundHandleMouseMove,!0),document.removeEventListener("keydown",this.boundHandleKeyDown,!0),window.removeEventListener("scroll",this.boundHandleScroll,!0),this.highlightOverlay.hide(),this.highlightOverlay.unmount(),this.alignmentGuides.hide(),this.alignmentGuides.unmount(),document.body.style.cursor="",this.currentElement=null,this.layerNavigator.reset(),(t=(e=this.callbacks).onDeactivate)==null||t.call(e))}toggle(){this.isActive?this.deactivate():this.activate()}getIsActive(){return this.isActive}handleMouseMove(e){if(!this.isActive)return;const t=e.target;if(t.closest("[data-redline-guides]")||t.closest("[data-redline-overlay]")||t.closest("[data-redline-ui]"))return;this.layerNavigator.updateAtPoint(e.clientX,e.clientY);const i=this.layerNavigator.getCurrentElement();i&&(i!==this.currentElement&&this.resetChildrenDepth(),this.currentElement=i,this.alignmentGuides.showGuides(i),this.syncHighlightOverlay(i))}syncHighlightOverlay(e){this.highlightOverlay.highlight(e,{typography:this.styleAnalyzer.extractTypographyStyles(e)})}handleKeyDown(e){if(!this.isActive)return;const t=e.target,s=e.composedPath()[0];if(!((t.tagName==="INPUT"||t.tagName==="TEXTAREA"||s.tagName==="INPUT"||s.tagName==="TEXTAREA")&&e.key!=="Escape"))switch(e.key){case"Escape":this.deactivate(),e.preventDefault();break;case"ArrowUp":e.preventDefault(),this.resetChildrenDepth(),this.layerNavigator.navigateUp(),this.applyCurrentNavigatorElement();break;case"ArrowDown":if(e.preventDefault(),!this.currentElement)break;this.childrenDepth+=1;const r=this.collectDescendantsAtDepth(this.currentElement,this.childrenDepth);r.length===0?this.childrenDepth-=1:this.highlightOverlay.highlightChildren(r);break;case"ArrowRight":e.preventDefault(),this.resetChildrenDepth(),this.layerNavigator.navigateNext(),this.applyCurrentNavigatorElement();break;case"ArrowLeft":e.preventDefault(),this.resetChildrenDepth(),this.layerNavigator.navigatePrevious(),this.applyCurrentNavigatorElement();break}}handleScroll(){!this.isActive||!this.currentElement||(this.alignmentGuides.showGuides(this.currentElement),this.syncHighlightOverlay(this.currentElement))}applyCurrentNavigatorElement(){const e=this.layerNavigator.getCurrentElement();e&&(this.currentElement=e,this.alignmentGuides.showGuides(e),this.syncHighlightOverlay(e))}resetChildrenDepth(){this.childrenDepth=0,this.highlightOverlay.clearChildrenHighlight()}collectDescendantsAtDepth(e,t){if(t<=0)return[];let i=[e];for(let s=0;s<t;s++){const n=[];for(const r of i)for(const l of Array.from(r.children)){if(l.hasAttribute("data-redline-overlay")||l.hasAttribute("data-redline-panel")||l.hasAttribute("data-redline-ui")||l.hasAttribute("data-redline-badges"))continue;const d=l.getBoundingClientRect();d.width===0||d.height===0||n.push(l)}if(i=n,i.length===0)break}return i}}const m=class m{constructor(e){a(this,"container",null);a(this,"redlineButton",null);a(this,"collapseButton",null);a(this,"buttonsContainer",null);a(this,"callbacks");a(this,"isCollapsed",!1);a(this,"isDragging",!1);a(this,"dragStartX",0);a(this,"dragStartLeft",0);a(this,"boundHandleDragStart",null);a(this,"boundHandleDragMove",null);a(this,"boundHandleDragEnd",null);a(this,"boundHandleDoubleClick",null);a(this,"expandActivationTimeout",null);this.callbacks=e}mount(){this.container||(this.createElements(),this.attachStyles(),this.attachEventListeners(),this.container.classList.add("redline-no-transition"),this.container.style.display="none",document.body.appendChild(this.container),Promise.all([this.loadCollapseState(),this.loadPosition()]).then(()=>{requestAnimationFrame(()=>{requestAnimationFrame(()=>{var e;(e=this.container)==null||e.classList.remove("redline-no-transition")})})}))}unmount(){this.container&&(this.boundHandleDragStart&&this.container.removeEventListener("mousedown",this.boundHandleDragStart),this.boundHandleDoubleClick&&this.container.removeEventListener("dblclick",this.boundHandleDoubleClick),this.boundHandleDragMove&&document.removeEventListener("mousemove",this.boundHandleDragMove),this.boundHandleDragEnd&&document.removeEventListener("mouseup",this.boundHandleDragEnd),this.container.remove(),this.container=null,this.redlineButton=null,this.collapseButton=null,this.buttonsContainer=null,this.boundHandleDragStart=null,this.boundHandleDragMove=null,this.boundHandleDragEnd=null,this.boundHandleDoubleClick=null)}show(){this.container&&(this.container.style.display="flex")}hide(){this.container&&(this.container.style.display="none")}setRedlineActive(e){if(this.redlineButton){const t=e?m.ICON_ACTIVE:m.ICON_INACTIVE,i='<span class="btn-tooltip">Redline</span>';this.redlineButton.innerHTML=t+i,this.redlineButton.classList.toggle("redline-fab--active",e),this.redlineButton.setAttribute("aria-pressed",String(e))}}createElements(){this.container=document.createElement("div"),this.container.id="redline-floating-button",this.container.setAttribute("data-redline-ui","true"),this.buttonsContainer=document.createElement("div"),this.buttonsContainer.className="redline-buttons-container",this.redlineButton=document.createElement("button"),this.redlineButton.className="redline-fab",this.redlineButton.innerHTML=`
      ${m.ICON_INACTIVE}
      <span class="btn-tooltip">Redline</span>
    `,this.redlineButton.setAttribute("aria-label","Toggle Redline Mode"),this.redlineButton.setAttribute("aria-pressed","false"),this.collapseButton=document.createElement("button"),this.collapseButton.className="redline-collapse-btn",this.collapseButton.innerHTML=m.ICON_CHEVRON_DOWN,this.collapseButton.setAttribute("aria-label","Collapse buttons"),this.collapseButton.title="Collapse buttons",this.buttonsContainer.appendChild(this.redlineButton),this.buttonsContainer.appendChild(this.collapseButton),this.container.appendChild(this.buttonsContainer)}attachStyles(){const e="redline-fab-styles";if(document.getElementById(e))return;const t=document.createElement("style");t.id=e,t.textContent=`
      #redline-floating-button {
        position: fixed;
        bottom: 8px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483646;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        transition: bottom 0.2s ease;
        cursor: grab;
      }

      #redline-floating-button.dragging {
        cursor: grabbing;
        transition: none;
      }

      /* Suppress all transitions while initial persisted state is being applied
         (collapse + position) so reloads don't animate from defaults. */
      #redline-floating-button.redline-no-transition,
      #redline-floating-button.redline-no-transition *,
      #redline-floating-button.redline-no-transition *::before,
      #redline-floating-button.redline-no-transition *::after {
        transition: none !important;
        animation: none !important;
      }

      /* Container content wrapper */
      .redline-buttons-container {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        padding: 4px;
        background: #000000;
        border: 1px solid rgba(255, 255, 255, 0.15);
        border-radius: 24px;
        box-shadow: 
          0 4px 12px rgba(0, 0, 0, 0.15),
          0 1px 3px rgba(0, 0, 0, 0.1);
        user-select: none;
        transition: all 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
      }

      .redline-fab {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border: none;
        border-radius: 50%;
        background: transparent;
        color: white;
        cursor: pointer;
        transition: all 0.45s cubic-bezier(0.34, 1.35, 0.64, 1), 
                    filter 0.45s cubic-bezier(0.34, 1.35, 0.64, 1),
                    transform 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
        outline: none;
        padding: 0;
        position: relative;
      }

      .redline-fab:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
      }

      .redline-fab:active {
        background: rgba(255, 255, 255, 0.15);
      }

      .redline-fab--active {
        background: #e63946;
        color: white;
      }

      .redline-fab--active:hover {
        background: #d62839;
        color: white;
      }

      .redline-fab svg {
        flex-shrink: 0;
      }

      /* Tooltip styling - unified */
      .btn-tooltip {
        position: absolute;
        bottom: calc(100% + 8px);
        left: 50%;
        transform: translateX(-50%) translateY(4px);
        ${O("small")}
        opacity: 0;
        transition: opacity 0.2s ease, transform 0.2s ease;
        z-index: 1000;
      }

      .redline-fab:hover .btn-tooltip {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
      }

      /* Collapse button - looks like part of the container when expanded */
      .redline-collapse-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 32px;
        height: 32px;
        border: none;
        border-radius: 50%;
        background: transparent;
        color: white;
        cursor: pointer;
        transition: all 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
        outline: none;
        padding: 0;
      }

      .redline-collapse-btn svg {
        flex-shrink: 0;
        transition: transform 0.45s cubic-bezier(0.34, 1.35, 0.64, 1);
      }

      .redline-collapse-btn:hover {
        background: rgba(255, 255, 255, 0.1);
        color: white;
      }

      .redline-collapse-btn:active {
        background: rgba(255, 255, 255, 0.15);
      }

      /* Collapsed state - slide down and show only chevron */
      #redline-floating-button.collapsed {
        bottom: 0px;
      }

      #redline-floating-button.collapsed .redline-buttons-container {
        border-radius: 8px 8px 0 0;
        box-shadow: 
          0 -2px 8px rgba(0, 0, 0, 0.15);
        padding: 2px;
        gap: 0px;
        width: fit-content;
        margin: 0 auto;
      }

      #redline-floating-button.collapsed .redline-fab {
        width: 0;
        height: 0;
        min-width: 0;
        min-height: 0;
        padding: 0;
        margin: 0;
        opacity: 0;
        overflow: hidden;
        filter: blur(4px);
        transform: scale(0.3);
      }

      #redline-floating-button.collapsed .redline-collapse-btn {
        width: 24px;
        height: 16px;
        border-radius: 6px 6px 0 0;
        margin: 0;
      }

      #redline-floating-button.collapsed .redline-collapse-btn svg {
        transform: rotate(180deg);
      }
    `,document.head.appendChild(t)}attachEventListeners(){var t,i,s,n;const e=r=>{r.key===" "&&(r.preventDefault(),r.stopPropagation())};(t=this.redlineButton)==null||t.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),this.callbacks.onToggleRedline()}),(i=this.redlineButton)==null||i.addEventListener("keydown",e),(s=this.collapseButton)==null||s.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),this.toggleCollapse()}),(n=this.collapseButton)==null||n.addEventListener("keydown",e),this.boundHandleDragStart=this.handleDragStart.bind(this),this.boundHandleDragMove=this.handleDragMove.bind(this),this.boundHandleDragEnd=this.handleDragEnd.bind(this),this.container&&this.container.addEventListener("mousedown",this.boundHandleDragStart),document.addEventListener("mousemove",this.boundHandleDragMove),document.addEventListener("mouseup",this.boundHandleDragEnd),this.boundHandleDoubleClick=this.handleDoubleClick.bind(this),this.container&&this.container.addEventListener("dblclick",this.boundHandleDoubleClick)}getIsCollapsed(){return this.isCollapsed}expand(){var e,t,i;this.isCollapsed&&(this.isCollapsed=!1,this.saveCollapseState(),this.container&&(this.container.classList.remove("collapsed"),(e=this.collapseButton)==null||e.setAttribute("aria-label","Collapse buttons"),this.collapseButton&&(this.collapseButton.title="Collapse buttons")),(i=(t=this.callbacks).onCollapse)==null||i.call(t,!1))}toggleCollapse(){var t,i,s,n;const e=this.isCollapsed;this.isCollapsed=!this.isCollapsed,this.saveCollapseState(),this.container&&(this.isCollapsed?(this.container.classList.add("collapsed"),(t=this.collapseButton)==null||t.setAttribute("aria-label","Expand buttons"),this.collapseButton.title="Expand buttons"):(this.container.classList.remove("collapsed"),(i=this.collapseButton)==null||i.setAttribute("aria-label","Collapse buttons"),this.collapseButton.title="Collapse buttons")),(n=(s=this.callbacks).onCollapse)==null||n.call(s,this.isCollapsed),e&&!this.isCollapsed&&this.scheduleRedlineActivationOnExpand()}scheduleRedlineActivationOnExpand(){this.expandActivationTimeout&&(window.clearTimeout(this.expandActivationTimeout),this.expandActivationTimeout=null);const e=this.buttonsContainer;if(!e){this.callbacks.onToggleRedline();return}let t=!1;const i=()=>{t||(t=!0,e.removeEventListener("transitionend",s),this.expandActivationTimeout&&(window.clearTimeout(this.expandActivationTimeout),this.expandActivationTimeout=null),this.callbacks.onToggleRedline())},s=n=>{n.target===e&&i()};e.addEventListener("transitionend",s),this.expandActivationTimeout=window.setTimeout(i,500)}async loadCollapseState(){var e,t;try{const s=(await chrome.storage.local.get(m.STORAGE_KEY))[m.STORAGE_KEY];(s===!0||s==="true")&&(this.isCollapsed=!0,(e=this.container)==null||e.classList.add("collapsed"),(t=this.collapseButton)==null||t.setAttribute("aria-label","Expand buttons"),this.collapseButton.title="Expand buttons")}catch(i){console.warn("Failed to load collapse state:",i)}}async saveCollapseState(){try{await chrome.storage.local.set({[m.STORAGE_KEY]:this.isCollapsed})}catch(e){console.warn("Failed to save collapse state:",e)}}handleDragStart(e){if(!e.target.closest(".redline-fab, .redline-collapse-btn")){if(this.isDragging=!0,this.dragStartX=e.clientX,this.container){const t=this.container.getBoundingClientRect();this.dragStartLeft=t.left+t.width/2,this.container.classList.add("dragging")}e.preventDefault()}}handleDragMove(e){if(!this.isDragging||!this.container)return;const t=e.clientX-this.dragStartX;let i=this.dragStartLeft+t;const s=window.innerWidth,n=s/2,r=Math.abs(i-n),l=60;if(r<l){const o=1-r/l,h=(n-i)*o*.3;i+=h}const d=i/s*100;this.container.style.left=`${d}%`}handleDragEnd(){if(this.isDragging&&(this.isDragging=!1,this.container)){this.container.classList.remove("dragging");const e=this.container.getBoundingClientRect(),t=e.left+e.width/2,i=window.innerWidth/2;Math.abs(t-i)<40?this.centerContainer():this.savePosition()}}handleDoubleClick(e){e.target.closest(".redline-fab, .redline-collapse-btn")||this.centerContainer()}centerContainer(){this.container&&(this.container.style.left="50%",this.savePosition())}async loadPosition(){try{const t=(await chrome.storage.local.get(m.STORAGE_POSITION_KEY))[m.STORAGE_POSITION_KEY];typeof t=="string"&&this.container&&(this.container.style.left=t)}catch(e){console.warn("Failed to load position:",e)}}async savePosition(){try{if(this.container){const e=this.container.style.left||"50%";await chrome.storage.local.set({[m.STORAGE_POSITION_KEY]:e})}}catch(e){console.warn("Failed to save position:",e)}}};a(m,"STORAGE_KEY","redline-floating-button-collapsed"),a(m,"STORAGE_POSITION_KEY","redline-floating-button-position"),a(m,"ICON_INACTIVE",`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M10 15v-3"/>
      <path d="M14 15v-3"/>
      <path d="M18 15v-3"/>
      <path d="M2 8V4"/>
      <path d="M22 6H2"/>
      <path d="M22 8V4"/>
      <path d="M6 15v-3"/>
      <rect x="2" y="12" width="20" height="8" rx="2"/>
    </svg>
  `),a(m,"ICON_ACTIVE",`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M10 15v-3"/>
      <path d="M14 15v-3"/>
      <path d="M18 15v-3"/>
      <path d="M2 8V4"/>
      <path d="M22 6H2"/>
      <path d="M22 8V4"/>
      <path d="M6 15v-3"/>
      <rect x="2" y="12" width="20" height="8" rx="2"/>
    </svg>
  `),a(m,"ICON_CHEVRON_DOWN",`
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="m6 9 6 6 6-6"/>
    </svg>
  `);let k=m;const H="redline-content-script-loaded";if(!document.getElementById(H)){const u=document.createElement("meta");u.id=H,u.setAttribute("data-redline-ui","true"),(document.head||document.documentElement).appendChild(u),z()}function z(){let u,e=null;function t(){const o=n.getIsActive();u.setRedlineActive(o),i(o),chrome.runtime.sendMessage({type:"STATE_CHANGED",isActive:o})}function i(o){e!==o&&(e=o,chrome.storage.local.set({redlineIsActive:o}))}async function s(){const h=(await chrome.storage.local.get({redlineIsActive:!1})).redlineIsActive===!0;e=h,h&&!n.getIsActive()&&(n.activate(),t())}const n=new R({onDeactivate:()=>t()});u=new k({onToggleRedline:()=>{n.getIsActive()?n.deactivate():n.activate(),t()},onCollapse:o=>{o&&n.getIsActive()&&(n.deactivate(),t())}});const r="redline-floating-button-hidden";u.mount(),chrome.storage.local.get({[r]:!1}).then(o=>{o[r]===!0?(u.hide(),n.getIsActive()&&(n.deactivate(),t())):u.show()}),s(),chrome.storage.onChanged.addListener((o,h)=>{if(h==="local"){if(o.redlineIsActive){const c=o.redlineIsActive.newValue===!0;e=c,c&&!n.getIsActive()?(n.activate(),t()):!c&&n.getIsActive()&&(n.deactivate(),t())}o[r]&&(o[r].newValue===!0?(n.getIsActive()&&(n.deactivate(),t()),u.hide()):u.show())}});function l(){u.getIsCollapsed()?(u.expand(),n.getIsActive()||n.activate()):n.getIsActive()?n.deactivate():n.activate(),t()}chrome.runtime.onMessage.addListener((o,h,c)=>{switch(o.type){case"TOGGLE_INSPECTION":{l(),c({success:!0});return}case"GET_STATE":c({isActive:n.getIsActive()});return}});function d(o){if(o.repeat||!o.shiftKey)return!1;const h=o.metaKey||o.ctrlKey;return!!(o.code==="KeyR"&&o.altKey&&!h||o.code==="KeyL"&&h&&!o.altKey)}document.addEventListener("keydown",o=>{d(o)&&(o.preventDefault(),o.stopPropagation(),l())},!0)}
